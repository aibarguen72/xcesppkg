#!/usr/bin/env python3
"""
config-to-objects/interface.py — XCESP-ON-RTR
Maps an 'interface' config node to one RtrInterface xcespproc object.

Multiple IP addresses are collected from child 'address' nodes whose
instance names carry the IP/prefix (e.g. "10.10.10.10/24").
Namespace and VRF are derived from NODE_PATH injected by xcespmap.

IFACE_TYPE values:
  device   (default) — existing Linux device; check existence, sync IPs
  loopback           — dummy interface (or standard 'lo'); create if needed
  rlink              — veth pair endpoint; LINK carries the shared link name
  gre                — GRE tunnel; GRE_* attrs carry tunnel parameters
  vlan               — 802.1Q VLAN sub-interface; VLAN_* attrs carry parameters
  bridge             — Linux bridge; BRIDGE_PORT_* attrs carry port list
"""

NEEDS_FULL_CONFIG = True


def run(data):
    attrs  = data["attrs"]
    iface_type = attrs.get("type", "device")
    # For rlink/gre/vlan/bridge, 'device' is optional and defaults to instance name
    device = attrs.get("device", data["instance_name"])
    addresses = ",".join(
        a["instance_name"]
        for a in data.get("children", {}).get("address", [])
    )
    obj = {
        "section": f"object.iface-{data['instance_name']}",
        "attrs": {
            "TYPE":       "RtrInterface",
            "NAME":       "interface_" + data["instance_name"],
            "DEVICE":     device,
            "IFACE_TYPE": iface_type,
            "LINK":       attrs.get("link", ""),
            "ADDRESSES":  addresses,
            "SHUTDOWN":   attrs.get("shutdown", "true"),
            "MPLS":       attrs.get("mpls",     "false"),
        },
    }

    gre_block = data.get("children", {}).get("gre", [])
    if gre_block:
        g = gre_block[0].get("attrs", {})
        obj["attrs"]["GRE_SOURCE"]      = g.get("source",      "")
        obj["attrs"]["GRE_DESTINATION"] = g.get("destination", "")
        obj["attrs"]["GRE_INTERFACE"]   = g.get("interface",   "")
        obj["attrs"]["GRE_KEY"]         = str(g.get("key", ""))
        obj["attrs"]["GRE_TTL"]         = str(g.get("ttl", ""))

        nhrp_nodes = gre_block[0].get("children", {}).get("nhrp", [])
        if nhrp_nodes:
            n  = nhrp_nodes[0]
            na = n.get("attrs", {})
            obj["attrs"]["NHRP_ENABLED"]               = "true"
            obj["attrs"]["NHRP_AUTH"]                  = na.get("authentication", "")
            obj["attrs"]["NHRP_HOLDTIME"]              = str(na.get("holdtime", ""))
            obj["attrs"]["NHRP_NETWORK_ID"]            = str(na.get("network-id", ""))
            obj["attrs"]["NHRP_MTU"]                   = str(na.get("mtu", ""))
            obj["attrs"]["NHRP_REGISTRATION_NO_UNIQUE"] = str(na.get("registration-no-unique", "false"))
            obj["attrs"]["NHRP_SHORTCUT"]              = str(na.get("shortcut", "false"))
            maps = n.get("children", {}).get("nhrp-map", [])
            obj["attrs"]["NHRP_MAPS"] = ",".join(
                f"{m['instance_name']}:{m['attrs']['nbma']}" for m in maps)
            nhs_list = n.get("children", {}).get("nhrp-nhs", [])
            obj["attrs"]["NHRP_NHS"] = ",".join(
                f"{s['instance_name']}:{s['attrs']['nbma']}" for s in nhs_list)

    # VLAN sub-interface
    vlan_block = data.get("children", {}).get("vlan", [])
    if iface_type == "vlan" and vlan_block:
        vb = vlan_block[0]
        va = vb.get("attrs", {})
        vlan_id       = str(va.get("vlanid", "0"))
        parent_if     = va.get("interface", "")
        parent_router = va.get("parent-router", "")

        # Build siblings map: instance_name → node
        siblings = {
            i["instance_name"]: i
            for i in data.get("parent", {}).get("children", {}).get("interface", [])
        }

        if parent_router:
            # Cross-NS: resolve parent device from full config tree
            parent_device = ""
            for rtr in data.get("config", {}).get("router", []):
                if rtr["instance_name"] != parent_router:
                    continue
                for vrf_node in rtr.get("children", {}).get("vrf", []):
                    for iface in vrf_node.get("children", {}).get("interface", []):
                        if iface["instance_name"] == parent_if:
                            parent_device = iface["attrs"].get("device", parent_if)
                            break
            parent_ns = parent_router
            # Cross-NS: device defaults to instance name (becomes macvlan name)
        else:
            # Same-NS: resolve parent device from sibling interface
            sibling = siblings.get(parent_if, {})
            parent_device = sibling.get("attrs", {}).get("device", parent_if)
            parent_ns = ""
            # Same-NS: Linux device = {parent_device}.{vlan_id} (unless overridden)
            if not attrs.get("device"):
                device = f"{parent_device}.{vlan_id}"
                obj["attrs"]["DEVICE"] = device

        obj["attrs"]["VLAN_ID"]            = vlan_id
        obj["attrs"]["VLAN_PARENT_DEVICE"] = parent_device
        obj["attrs"]["VLAN_PARENT_NS"]     = parent_ns

    # Bridge
    bridge_block = data.get("children", {}).get("bridge", [])
    if iface_type == "bridge" and bridge_block:
        bb = bridge_block[0]
        siblings = {
            i["instance_name"]: i
            for i in data.get("parent", {}).get("children", {}).get("interface", [])
        }
        port_count = 0
        for port in bb.get("children", {}).get("port", []):
            pname   = port["instance_name"]
            ref_if  = port.get("attrs", {}).get("interface", "")
            sibling = siblings.get(ref_if, {})
            sibling_attrs = sibling.get("attrs", {})
            sibling_type  = sibling_attrs.get("type", "device")
            if sibling_type == "vlan":
                # Resolve VLAN port device name from sub-block
                vb2 = (sibling.get("children", {}).get("vlan") or [{}])[0]
                parent_if2 = vb2.get("attrs", {}).get("interface", "")
                vlan_id2   = str(vb2.get("attrs", {}).get("vlanid", "0"))
                parent_sib = siblings.get(parent_if2, {})
                parent_dev = parent_sib.get("attrs", {}).get("device", parent_if2)
                port_device = f"{parent_dev}.{vlan_id2}"
            else:
                port_device = sibling_attrs.get("device", ref_if)
            if port_device:
                obj["attrs"][f"BRIDGE_PORT_{port_count}_NAME"]   = pname
                obj["attrs"][f"BRIDGE_PORT_{port_count}_DEVICE"] = port_device
                port_count += 1
        obj["attrs"]["BRIDGE_PORT_COUNT"] = str(port_count)

    # VRRP groups
    vrrp_groups = data.get("children", {}).get("vrrp", [])
    if vrrp_groups:
        count = 0
        for vg in vrrp_groups:
            vg_id = vg.get("instance_name", "0")
            va    = vg.get("attrs", {})
            addresses = ",".join(
                a["instance_name"]
                for a in vg.get("children", {}).get("address", [])
            )
            obj["attrs"][f"VRRP_{count}_ID"]          = vg_id
            obj["attrs"][f"VRRP_{count}_VERSION"]     = str(va.get("version",                      ""))
            obj["attrs"][f"VRRP_{count}_PRIORITY"]    = str(va.get("priority",                     ""))
            obj["attrs"][f"VRRP_{count}_PREEMPT"]     = str(va.get("preempt",                      ""))
            obj["attrs"][f"VRRP_{count}_ADV_INTERVAL"]= str(va.get("advertisement-interval",       ""))
            obj["attrs"][f"VRRP_{count}_CHECKSUM"]    = str(va.get("checksum-with-ipv4-pseudoheader", "true"))
            obj["attrs"][f"VRRP_{count}_SHUTDOWN"]    = str(va.get("shutdown",                     "false"))
            obj["attrs"][f"VRRP_{count}_ADDRESSES"]   = addresses
            count += 1
        obj["attrs"]["VRRP_COUNT"] = str(count)

    # force-symmetry: emit a companion RtrForceSymmetry object when enabled
    force_sym = attrs.get("force-symmetry", "false").lower() in ("true", "1", "yes")
    if force_sym:
        import hashlib
        # Resolve NS and VRF from parent chain: data["parent"] is the vrf node,
        # its parent is the router node.
        vrf_node_p = data.get("parent", {})
        vrf_inst   = vrf_node_p.get("instance_name", "default")
        rtr_node_p = vrf_node_p.get("parent", {})
        ns_inst    = rtr_node_p.get("instance_name", "")
        h    = int(hashlib.md5(f"{ns_inst}:{vrf_inst}:{device}".encode()).hexdigest(), 16)
        mark = h & 0xFFFFF   # 20-bit deterministic mark
        sym_obj = {
            "section": f"object.forcesym-{device}",
            "attrs": {
                "TYPE":   "RtrForceSymmetry",
                "NAME":   f"forcesym_{device}",
                "NS":     ns_inst,
                "VRF":    vrf_inst,
                "DEVICE": device,
                "MARK":   str(mark),
            },
        }
        return [obj, sym_obj]

    return [obj]
