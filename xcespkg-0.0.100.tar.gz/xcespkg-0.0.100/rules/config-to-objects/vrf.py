#!/usr/bin/env python3
"""
config-to-objects/vrf.py — XCESP-ON-RTR
Maps a 'vrf' config node to one RtrVrf xcespproc object.

Also emits RtrBgp objects for each bgp/bgp-vrf/bgp-view child block:
  bgp <ASN>        → BGP_TYPE "main" (vrf default) or "vrf-kernel" (named vrf)
  bgp-vrf <NAME>   → BGP_TYPE "vrf-bgp"  (ASN inherited from sibling bgp)
  bgp-view <NAME>  → BGP_TYPE "view"     (ASN inherited from sibling bgp)

The vrf instance name becomes the Linux VRF device name.
"default" is the default routing table (no VRF device is created).
An optional TABLE attr overrides the auto-assigned routing table number.

Namespace is NOT available in this rule; RtrBgpPObj derives it from
NODE_PATH (format: router/<ns>/vrf/<vrf>) injected by xcespmap.

BGP-PARAMS CHILD:
Each bgp/bgp-vrf/bgp-view block may contain an optional singleton child
"bgp-params" with boolean flags, integer attrs, and a grandchild
"bgp-dampening" for route dampening parameters. All values are passed as
distinct INI keys to RtrBgpPObj. Absent keys use 0/"false" as sentinels
(never emitted to FRR config).

NEIGHBOR / GROUP / LISTEN CHILDREN:
Each bgp/bgp-vrf/bgp-view block may contain multi-instance children:
  neighbor <IP|interface>  — static BGP peer (remote-as or remote-as-auto)
  group <NAME>             — peer-group declaration
  listen <PREFIX>          — dynamic peer listen range with mandatory group

These are serialised as indexed INI keys (NEIGHBOR_COUNT, NEIGHBOR_0, ...)
and reassembled by RtrBgpPObj into the FRR fragment in the correct order
(group declarations first, then neighbors, then listen ranges).
"""

import ipaddress


def _is_ip(s):
    """Return True if s is a valid IPv4 or IPv6 address (not a prefix)."""
    try:
        ipaddress.ip_address(s)
        return True
    except ValueError:
        return False


# Simple booleans: same XCESPCLI name and FRR name
_SIMPLE_BOOLS = [
    "disable-connected-check", "disable-link-bw-encoding-ieee",
    "extended-link-bandwidth", "enforce-first-as",
    "extended-optional-parameters", "ebgp-multihop", "ip-transparent",
    "send-nexthop-characteristics", "as-override", "addpath-tx-all-paths",
    "addpath-tx-bestpath-per-AS", "disable-addpath-rx", "accept-own",
    "graceful-shutdown",
    "graceful-restart", "graceful-restart-helper", "graceful-restart-disable",
    "default-originate", "sender-as-path-loop-detection",
]

# Compound-name booleans: XCESPCLI name → FRR suffix after "neighbor <P> "
_COMPOUND_BOOL_MAP = {
    "send-community-extended-rpki": "send-community extended rpki",
    "soft-reconfiguration-inbound": "soft-reconfiguration inbound",
    "capability-extended-nexthop":  "capability extended-nexthop",
    "capability-dynamic":           "capability dynamic",
    "capability-fqdn":              "capability fqdn",
    "capability-link-local":        "capability link-local",
}

# Simple integer neighbor params: (XCESPCLI attr, FRR suffix)
_SIMPLE_INTS = [
    ("port",                             "port"),
    ("weight",                           "weight"),
    ("maximum-prefix",                   "maximum-prefix"),
    ("maximum-prefix-out",               "maximum-prefix-out"),
    ("addpath-tx-best-selected",         "addpath-tx-best-selected"),
    ("addpath-rx-paths-limit",           "addpath-rx-paths-limit"),
    ("ttl-security-hops",                "ttl-security hops"),
    ("path-attribute-discard",           "path-attribute discard"),
    ("path-attribute-treat-as-withdraw", "path-attribute treat-as-withdraw"),
    ("advertisement-interval",           "advertisement-interval"),
]


def _is_true(v):
    return v in ("true", "True", "TRUE", True)


def _emit_peer_params(peer, attrs, children, iface_to_device=None):
    """Emit FRR neighbor param lines for one peer (neighbor or group)."""
    lines = []
    a = attrs

    # A) Shutdown / auto-shutdown (auto-shutdown takes priority)
    # Always emit the shutdown state explicitly so that vtysh -f (additive apply)
    # clears a previously-set shutdown when the config is removed.
    auto_sd = (children or {}).get("auto-shutdown", [])
    if auto_sd:
        sa = auto_sd[0].get("attrs", {})
        cmd = f" neighbor {peer} shutdown"
        if sa.get("message"):
            cmd += f" message {sa['message']}"
        if sa.get("rtt"):
            cmd += f" rtt {sa['rtt']}"
            if sa.get("count"):
                cmd += f" count {sa['count']}"
        lines.append(cmd)
    elif _is_true(a.get("shutdown")):
        lines.append(f" neighbor {peer} shutdown")
    else:
        lines.append(f" no neighbor {peer} shutdown")

    # B) Simple booleans
    for flag in _SIMPLE_BOOLS:
        if _is_true(a.get(flag)):
            lines.append(f" neighbor {peer} {flag}")

    # C) next-hop-self / next-hop-self-force (force takes priority)
    if _is_true(a.get("next-hop-self-force")):
        lines.append(f" neighbor {peer} next-hop-self force")
    elif _is_true(a.get("next-hop-self")):
        lines.append(f" neighbor {peer} next-hop-self")

    # D) Compound-name booleans
    for xcli_name, frr_suffix in _COMPOUND_BOOL_MAP.items():
        if _is_true(a.get(xcli_name)):
            lines.append(f" neighbor {peer} {frr_suffix}")

    # E) attribute-unchanged compound line (combine flags into one command)
    au_flags = []
    if _is_true(a.get("attribute-unchanged-as-path")):  au_flags.append("as-path")
    if _is_true(a.get("attribute-unchanged-next-hop")):  au_flags.append("next-hop")
    if _is_true(a.get("attribute-unchanged-med")):       au_flags.append("med")
    if au_flags:
        lines.append(f" neighbor {peer} attribute-unchanged {' '.join(au_flags)}")

    # F) send-community individual lines (each bit is separate FRR command)
    for sc_name, sc_frr in [("send-community-extended", "extended"),
                             ("send-community-standard", "standard"),
                             ("send-community-large",    "large")]:
        if _is_true(a.get(sc_name)):
            lines.append(f" neighbor {peer} send-community {sc_frr}")

    # G) Simple integer parameters
    for xcli, frr in _SIMPLE_INTS:
        val = a.get(xcli, "")
        if val and val != "0":
            lines.append(f" neighbor {peer} {frr} {val}")

    # H) local-as compound (integer + chained boolean flags)
    las = a.get("local-as", "")
    if las and las != "0":
        cmd = f" neighbor {peer} local-as {las}"
        if _is_true(a.get("local-as-no-prepend")):
            cmd += " no-prepend"
            if _is_true(a.get("local-as-replace-as")):
                cmd += " replace-as"
                if _is_true(a.get("local-as-dual-as")):
                    cmd += " dual-as"
        lines.append(cmd)

    # I) allowas-in compound (boolean + optional count)
    if _is_true(a.get("allowas-in")):
        cmd = f" neighbor {peer} allowas-in"
        cnt = a.get("allowas-in-count", "")
        if cnt and cnt != "0":
            cmd += f" {cnt}"
        lines.append(cmd)

    # J) timers compound (both keepalive + holdtime required for main timer)
    ka = a.get("timers-keepalive", "")
    ht = a.get("timers-holdtime", "")
    if ka and ht:
        lines.append(f" neighbor {peer} timers {ka} {ht}")
    tc = a.get("timers-connect", "")
    if tc and tc != "0":
        lines.append(f" neighbor {peer} timers connect {tc}")
    td = a.get("timers-delayopen", "")
    if td and td != "0":
        lines.append(f" neighbor {peer} timers delayopen {td}")

    # K) Neighbor dampening
    ndamp = (children or {}).get("nbr-dampening", [])
    if ndamp:
        da = ndamp[0].get("attrs", {})
        cmd = f" neighbor {peer} dampening"
        pen = da.get("penalty", "")
        if pen and pen != "0":
            cmd += f" {pen}"
            reuse = da.get("reuse", "")
            if reuse and reuse != "0":
                cmd += f" {reuse}"
                sup = da.get("suppress", "")
                if sup and sup != "0":
                    cmd += f" {sup}"
                    dur = da.get("duration", "")
                    if dur and dur != "0":
                        cmd += f" {dur}"
        lines.append(cmd)

    # L) String/IP parameters
    us = a.get("update-source", "")
    if us:
        # Resolve interface names to kernel device names
        if iface_to_device and not _is_ip(us):
            us = iface_to_device.get(us, us)
        lines.append(f" neighbor {peer} update-source {us}")
    desc = a.get("description", "")
    if desc:
        lines.append(f" neighbor {peer} description {desc}")
    pw = a.get("password", "")
    if pw:
        lines.append(f" neighbor {peer} password {pw}")

    return lines


def _build_neighbor_lines(bgp_node, iface_to_device):
    """Build the FRR neighbor/group/listen lines for one BGP instance.

    FRR requires this ordering:
      1. peer-group declarations + group params
      2. neighbor entries + neighbor params
      3. listen ranges

    For interface neighbors (instance name is not an IP), the kernel device
    name is substituted using iface_to_device.

    Returns a list of FRR command strings, each prefixed with one space.
    """
    children = bgp_node.get("children") or {}
    lines = []

    # 1. peer-group declarations + group params
    for grp in children.get("group", []):
        g_name = grp["instance_name"]
        ga     = grp.get("attrs", {})
        lines.append(f" neighbor {g_name} peer-group")
        # remote-as on the group itself (fixed takes priority over auto)
        remote_as      = ga.get("remote-as", "")
        remote_as_auto = ga.get("remote-as-auto", "")
        if remote_as:
            lines.append(f" neighbor {g_name} remote-as {remote_as}")
        elif remote_as_auto:
            lines.append(f" neighbor {g_name} remote-as {remote_as_auto}")
        lines.extend(_emit_peer_params(g_name, ga, grp.get("children"), iface_to_device))

    # 2. neighbor entries + neighbor params
    for nbr in children.get("neighbor", []):
        peer = nbr["instance_name"]
        a    = nbr.get("attrs", {})
        # Resolve interface name → kernel device name
        if not _is_ip(peer):
            peer = iface_to_device.get(peer, peer)
        # remote-as (fixed takes priority over auto)
        remote_as      = a.get("remote-as", "")
        remote_as_auto = a.get("remote-as-auto", "")
        if remote_as:
            lines.append(f" neighbor {peer} remote-as {remote_as}")
        elif remote_as_auto:
            lines.append(f" neighbor {peer} remote-as {remote_as_auto}")
        # peer-group assignment
        grp_name = a.get("group", "")
        if grp_name:
            lines.append(f" neighbor {peer} peer-group {grp_name}")
        # neighbor params
        lines.extend(_emit_peer_params(peer, a, nbr.get("children"), iface_to_device))

    # 3. listen ranges
    for lst in children.get("listen", []):
        prefix = lst["instance_name"]
        grp    = (lst.get("attrs") or {}).get("group", "")
        if grp:
            lines.append(f" bgp listen range {prefix} peer-group {grp}")

    # 4. network announcements
    for net in children.get("network", []):
        lines.append(f" network {net['instance_name']}")

    # 5. aggregate-address (one modifier at most, in priority order)
    for agg in children.get("aggregate-address", []):
        prefix = agg["instance_name"]
        a      = agg.get("attrs", {})
        cmd    = f" aggregate-address {prefix}"
        if a.get("origin"):
            cmd += f" origin {a['origin']}"
        elif _is_true(a.get("as-set")):
            cmd += " as-set"
        elif _is_true(a.get("summary-only")):
            cmd += " summary-only"
        elif _is_true(a.get("matching-MED-only")):
            cmd += " matching-MED-only"
        elif a.get("route-map"):
            cmd += f" route-map {a['route-map']}"
        elif a.get("suppress-map"):
            cmd += f" suppress-map {a['suppress-map']}"
        lines.append(cmd)

    # 6. redistribute
    for rd in children.get("redistribute", []):
        protocol = rd["instance_name"]
        # xcespproc installs routes directly via 'ip route add' (bypassing Zebra),
        # so FRR sees them as "kernel" routes, not "static".  Translate transparently.
        if protocol == "static":
            protocol = "kernel"
        a        = rd.get("attrs", {})
        cmd      = f" redistribute {protocol}"
        metric   = a.get("metric", "")
        if metric and metric != "0":
            cmd += f" metric {metric}"
        rmap = a.get("route-map", "")
        if rmap:
            cmd += f" route-map {rmap}"
        lines.append(cmd)

    # 7. address-family blocks (must come last — they are sub-stanzas with !)
    for af in children.get("address-family", []):
        af_name = af["instance_name"]
        # Convert "ipv4-unicast" → "ipv4 unicast", "l2vpn-evpn" → "l2vpn evpn"
        frr_af = af_name.replace("-", " ", 1)
        lines.append(f" address-family {frr_af}")
        af_children = af.get("children") or {}
        for af_nbr in af_children.get("af-neighbor", []):
            peer = af_nbr["instance_name"]
            a    = af_nbr.get("attrs", {})
            # Resolve interface names for af-neighbor too
            if not _is_ip(peer):
                peer = iface_to_device.get(peer, peer)
            if _is_true(a.get("active")):
                lines.append(f"  neighbor {peer} activate")
                _emit_af_neighbor_params(peer, a, af_nbr.get("children"), lines)
        _emit_af_params(af, lines)
        lines.append(" exit-address-family")

    return lines


def _emit_af_params(af, lines):
    """Emit FRR lines for unicast-only AF parameters (export/import/rd/rt/...).

    These are valid only when SAFI=unicast (ipv4-unicast or ipv6-unicast),
    enforced by router.validate.py Check 16. The emit logic does not check
    SAFI here — if the validator passed, all attrs are appropriate for context.
    """
    a = af.get("attrs", {})

    # Boolean export/import vpn
    if _is_true(a.get("export-vpn")):  lines.append("  export vpn")
    if _is_true(a.get("import-vpn")):  lines.append("  import vpn")

    # import vrf <NAME> + optional separate route-map command
    if a.get("import-vrf"):
        lines.append(f"  import vrf {a['import-vrf']}")
    if a.get("import-vrf-route-map"):
        lines.append(f"  import vrf route-map {a['import-vrf-route-map']}")

    # label vpn export — fixed > auto-per-next-hop > auto-per-vrf
    if a.get("label-vpn-export-fixed"):
        lines.append(f"  label vpn export {a['label-vpn-export-fixed']}")
    elif _is_true(a.get("label-vpn-export-auto-per-next-hop")):
        lines.append("  label vpn export auto")
        lines.append("  label vpn export allocation-mode per-nexthop")
    elif _is_true(a.get("label-vpn-export-auto-per-vrf")):
        lines.append("  label vpn export auto")
        lines.append("  label vpn export allocation-mode per-vrf")

    # nexthop / rd
    if a.get("nexthop-vpn-export"):
        lines.append(f"  nexthop vpn export {a['nexthop-vpn-export']}")
    if a.get("rd-vpn-export"):
        lines.append(f"  rd vpn export {a['rd-vpn-export']}")

    # route-map vpn import/export
    if a.get("route-map-vpn-export"):
        lines.append(f"  route-map vpn export {a['route-map-vpn-export']}")
    if a.get("route-map-vpn-import"):
        lines.append(f"  route-map vpn import {a['route-map-vpn-import']}")

    # rt / rt6 — convert ';' to space; "both" overrides import/export
    def _rt(s):
        return s.replace(";", " ")

    if a.get("rt-redirect-import"):
        lines.append(f"  rt redirect import {_rt(a['rt-redirect-import'])}")
    if a.get("rt-vpn-both"):
        lines.append(f"  rt vpn both {_rt(a['rt-vpn-both'])}")
    else:
        if a.get("rt-vpn-import"):
            lines.append(f"  rt vpn import {_rt(a['rt-vpn-import'])}")
        if a.get("rt-vpn-export"):
            lines.append(f"  rt vpn export {_rt(a['rt-vpn-export'])}")

    if a.get("rt6-redirect-import"):
        lines.append(f"  rt6 redirect import {_rt(a['rt6-redirect-import'])}")
    if a.get("rt6-vpn-both"):
        lines.append(f"  rt6 vpn both {_rt(a['rt6-vpn-both'])}")
    else:
        if a.get("rt6-vpn-import"):
            lines.append(f"  rt6 vpn import {_rt(a['rt6-vpn-import'])}")
        if a.get("rt6-vpn-export"):
            lines.append(f"  rt6 vpn export {_rt(a['rt6-vpn-export'])}")

    # sid vpn export — fixed > auto
    if a.get("sid-vpn-export-fixed"):
        lines.append(f"  sid vpn export {a['sid-vpn-export-fixed']}")
    elif _is_true(a.get("sid-vpn-export-auto")):
        lines.append("  sid vpn export auto")

    # af-redistribute (same shape as global redistribute, but indented for AF)
    af_children = af.get("children") or {}
    for rd in af_children.get("af-redistribute", []):
        protocol = rd["instance_name"]
        # xcespproc installs routes directly via 'ip route add' (bypassing Zebra),
        # so FRR sees them as "kernel" routes, not "static".  Translate transparently.
        if protocol == "static":
            protocol = "kernel"
        ra       = rd.get("attrs", {})
        cmd      = f"  redistribute {protocol}"
        metric   = ra.get("metric", "")
        if metric and metric != "0":
            cmd += f" metric {metric}"
        rmap = ra.get("route-map", "")
        if rmap:
            cmd += f" route-map {rmap}"
        lines.append(cmd)

    # ----- SAFI-restricted additional params (validator Check 17) -----

    # bgp dampening (reuses bgp-dampening child node shape)
    damp_list = af_children.get("bgp-dampening", [])
    if damp_list:
        da = damp_list[0].get("attrs", {})
        cmd = "  bgp dampening"
        pen = da.get("penalty", "")
        if pen and pen != "0":
            cmd += f" {pen}"
            reuse = da.get("reuse", "")
            if reuse and reuse != "0":
                cmd += f" {reuse}"
                sup = da.get("suppress", "")
                if sup and sup != "0":
                    cmd += f" {sup}"
                    dur = da.get("duration", "")
                    if dur and dur != "0":
                        cmd += f" {dur}"
        lines.append(cmd)

    # bgp retain route-target all
    if _is_true(a.get("bgp-retain-route-target-all")):
        lines.append("  bgp retain route-target all")

    # maximum-paths / maximum-paths-ibgp [equal-cluster-length]
    mp = a.get("maximum-paths", "")
    if mp and mp != "0":
        lines.append(f"  maximum-paths {mp}")
    mpi = a.get("maximum-paths-ibgp", "")
    if mpi and mpi != "0":
        cmd = f"  maximum-paths ibgp {mpi}"
        if _is_true(a.get("maximum-paths-ibgp-equal-cluster-length")):
            cmd += " equal-cluster-length"
        lines.append(cmd)

    # aggregate-address — same priority logic as global aggregate
    for agg in af_children.get("aggregate-address", []):
        prefix = agg["instance_name"]
        ag_a   = agg.get("attrs", {})
        cmd    = f"  aggregate-address {prefix}"
        if ag_a.get("origin"):
            cmd += f" origin {ag_a['origin']}"
        elif _is_true(ag_a.get("as-set")):
            cmd += " as-set"
        elif _is_true(ag_a.get("summary-only")):
            cmd += " summary-only"
        elif _is_true(ag_a.get("matching-MED-only")):
            cmd += " matching-MED-only"
        elif ag_a.get("route-map"):
            cmd += f" route-map {ag_a['route-map']}"
        elif ag_a.get("suppress-map"):
            cmd += f" suppress-map {ag_a['suppress-map']}"
        lines.append(cmd)

    # distance per-prefix entries
    for dist in af_children.get("af-distance", []):
        prefix = dist["instance_name"]
        da     = dist.get("attrs", {})
        d_val  = da.get("distance", "")
        if d_val and d_val != "0":
            cmd = f"  distance {d_val} {prefix}"
            acl = da.get("acl", "")
            if acl:
                cmd += f" {acl}"
            lines.append(cmd)

    # distance bgp <ext> <int> <local> — all three required
    de = a.get("distance-bgp-external", "")
    di = a.get("distance-bgp-internal", "")
    dl = a.get("distance-bgp-local", "")
    if de and di and dl and de != "0" and di != "0" and dl != "0":
        lines.append(f"  distance bgp {de} {di} {dl}")


_AF_NBR_SIMPLE_BOOLS = [
    "addpath-tx-all-paths", "addpath-tx-bestpath-per-AS",
    "as-override", "disable-addpath-rx",
    "route-reflector-client", "route-server-client",
]

_AF_NBR_SIMPLE_INTS = [
    ("addpath-rx-paths-limit",   "addpath-rx-paths-limit"),
    ("addpath-tx-best-selected", "addpath-tx-best-selected"),
    ("maximum-prefix-out",       "maximum-prefix-out"),
    ("weight",                   "weight"),
]

_AF_NBR_DIRECTION_PAIRS = [
    ("distribute-list-in",  "distribute-list", "in"),
    ("distribute-list-out", "distribute-list", "out"),
    ("filter-list-in",      "filter-list",     "in"),
    ("filter-list-out",     "filter-list",     "out"),
    ("prefix-list-in",      "prefix-list",     "in"),
    ("prefix-list-out",     "prefix-list",     "out"),
    ("route-map-in",        "route-map",       "in"),
    ("route-map-out",       "route-map",       "out"),
]


def _emit_af_neighbor_params(peer, a, children, lines):
    """Emit FRR neighbor sub-commands inside an address-family block.
    All lines are 2-space indented (one level deeper than 'address-family X Y').
    Called only when the neighbor's `active` is true.
    """
    # Simple booleans (single-word identical to FRR)
    for flag in _AF_NBR_SIMPLE_BOOLS:
        if _is_true(a.get(flag)):
            lines.append(f"  neighbor {peer} {flag}")

    # soft-reconfiguration inbound (compound name in FRR)
    if _is_true(a.get("soft-reconfiguration-inbound")):
        lines.append(f"  neighbor {peer} soft-reconfiguration inbound")

    # Integers
    for xcli, frr in _AF_NBR_SIMPLE_INTS:
        v = a.get(xcli, "")
        if v and v != "0":
            lines.append(f"  neighbor {peer} {frr} {v}")

    # attribute-unchanged compound (combine flags into one command)
    au = []
    if _is_true(a.get("attribute-unchanged-as-path")):  au.append("as-path")
    if _is_true(a.get("attribute-unchanged-next-hop")): au.append("next-hop")
    if _is_true(a.get("attribute-unchanged-med")):       au.append("med")
    if au:
        lines.append(f"  neighbor {peer} attribute-unchanged {' '.join(au)}")

    # allowas-in (count > origin > bare; mutually exclusive)
    aic = a.get("allowas-in-count", "")
    if aic and aic != "0":
        lines.append(f"  neighbor {peer} allowas-in {aic}")
    elif _is_true(a.get("allowas-in-origin")):
        lines.append(f"  neighbor {peer} allowas-in origin")
    elif _is_true(a.get("allowas-in")):
        lines.append(f"  neighbor {peer} allowas-in")

    # default-originate (bool + optional route-map)
    if _is_true(a.get("default-originate")):
        rmap = a.get("default-originate-route-map", "")
        if rmap:
            lines.append(f"  neighbor {peer} default-originate route-map {rmap}")
        else:
            lines.append(f"  neighbor {peer} default-originate")

    # Direction pairs (in/out)
    for xcli, frr_kw, direction in _AF_NBR_DIRECTION_PAIRS:
        v = a.get(xcli, "")
        if v:
            lines.append(f"  neighbor {peer} {frr_kw} {v} {direction}")

    # maximum-prefix compound (count + restart|warning + force)
    mp = a.get("maximum-prefix", "")
    if mp and mp != "0":
        cmd = f"  neighbor {peer} maximum-prefix {mp}"
        # restart and warning are mutually exclusive
        restart = a.get("maximum-prefix-restart", "")
        if restart and restart != "0":
            cmd += f" restart {restart}"
        elif _is_true(a.get("maximum-prefix-warning")):
            cmd += " warning"
        if _is_true(a.get("maximum-prefix-force")):
            cmd += " force"
        lines.append(cmd)

    # next-hop-self (force > all > bare; mutually exclusive)
    if _is_true(a.get("next-hop-self-force")):
        lines.append(f"  neighbor {peer} next-hop-self force")
    elif _is_true(a.get("next-hop-self-all")):
        lines.append(f"  neighbor {peer} next-hop-self all")
    elif _is_true(a.get("next-hop-self")):
        lines.append(f"  neighbor {peer} next-hop-self")

    # peer-group
    if a.get("peer-group"):
        lines.append(f"  neighbor {peer} peer-group {a['peer-group']}")

    # remove-private-AS (compound flags; only emit if base is true)
    if _is_true(a.get("remove-private-AS")):
        cmd = f"  neighbor {peer} remove-private-AS"
        if _is_true(a.get("remove-private-AS-all")):
            cmd += " all"
        if _is_true(a.get("remove-private-AS-replace-AS")):
            cmd += " replace-AS"
        lines.append(cmd)

    # send-community (mutually exclusive scope; priority all > both > extended > large > standard)
    for sc, scope in [
        ("send-community-all",      "all"),
        ("send-community-both",     "both"),
        ("send-community-extended", "extended"),
        ("send-community-large",    "large"),
        ("send-community-standard", "standard"),
    ]:
        if _is_true(a.get(sc)):
            lines.append(f"  neighbor {peer} send-community {scope}")
            break

    # soo, unsuppress-map
    if a.get("soo"):
        lines.append(f"  neighbor {peer} soo {a['soo']}")
    if a.get("unsuppress-map"):
        lines.append(f"  neighbor {peer} unsuppress-map {a['unsuppress-map']}")

    # capability orf prefix-list (mutually exclusive; priority both > receive > send)
    if _is_true(a.get("capability-orf-prefix-list-both")):
        lines.append(f"  neighbor {peer} capability orf prefix-list both")
    elif _is_true(a.get("capability-orf-prefix-list-receive")):
        lines.append(f"  neighbor {peer} capability orf prefix-list receive")
    elif _is_true(a.get("capability-orf-prefix-list-send")):
        lines.append(f"  neighbor {peer} capability orf prefix-list send")

    # af-nbr-dampening child (sequential FRR params)
    nc = children or {}
    damp_list = nc.get("af-nbr-dampening", [])
    if damp_list:
        da = damp_list[0].get("attrs", {})
        cmd = f"  neighbor {peer} dampening"
        pen = da.get("penalty", "")
        if pen and pen != "0":
            cmd += f" {pen}"
            reuse = da.get("reuse", "")
            if reuse and reuse != "0":
                cmd += f" {reuse}"
                sup = da.get("suppress", "")
                if sup and sup != "0":
                    cmd += f" {sup}"
                    dur = da.get("duration", "")
                    if dur and dur != "0":
                        cmd += f" {dur}"
        lines.append(cmd)

    # af-advertise-map child (instance name = primary route-map)
    adv_list = nc.get("af-advertise-map", [])
    if adv_list:
        adv = adv_list[0]
        rmap1 = adv["instance_name"]
        adv_a = adv.get("attrs", {})
        cmd = f"  neighbor {peer} advertise-map {rmap1}"
        if adv_a.get("exist-map"):
            cmd += f" exist-map {adv_a['exist-map']}"
        elif adv_a.get("non-exist-map"):
            cmd += f" non-exist-map {adv_a['non-exist-map']}"
        lines.append(cmd)


def _add_neighbor_keys(obj_attrs, bgp_node, iface_to_device):
    """Add indexed NEIGHBOR_COUNT / NEIGHBOR_N keys to an object attrs dict."""
    lines = _build_neighbor_lines(bgp_node, iface_to_device)
    obj_attrs["NEIGHBOR_COUNT"] = str(len(lines))
    for i, line in enumerate(lines):
        obj_attrs[f"NEIGHBOR_{i}"] = line


def _extract_bgp_params(bgp_node):
    """Extract bgp-params and bgp-dampening children into flat INI key dict."""
    bp_list   = (bgp_node.get("children") or {}).get("bgp-params", [])
    bp        = bp_list[0].get("attrs", {}) if bp_list else {}
    damp_list = ((bp_list[0].get("children") or {}).get("bgp-dampening", [])
                 if bp_list else [])
    damp      = damp_list[0].get("attrs", {}) if damp_list else {}

    return {
        # Boolean flags
        "BESTPATH_AS_PATH_CONFED":            bp.get("bestpath-as-path-confed",            "false"),
        "BESTPATH_AS_PATH_MULTIPATH_RELAX":   bp.get("bestpath-as-path-multipath-relax",   "false"),
        "BESTPATH_COMPARE_ROUTERID":          bp.get("bestpath-compare-routerid",          "false"),
        "BESTPATH_PEER_TYPE_MULTIPATH_RELAX": bp.get("bestpath-peer-type-multipath-relax", "false"),
        "BESTPATH_AIGP":                      bp.get("bestpath-aigp",                      "false"),
        "BESTPATH_USE_IMPORTED_ATTRIBUTES":   bp.get("bestpath-use-imported-attributes",   "false"),
        "BESTPATH_MED_MISSING_AS_WORST":      bp.get("bestpath-med-missing-as-worst",      "false"),
        "EBGP_REQUIRES_POLICY":              bp.get("ebgp-requires-policy",               "false"),
        "REJECT_AS_SETS":                    bp.get("reject-as-sets",                     "false"),
        "ENFORCE_FIRST_AS":                  bp.get("enforce-first-as",                   "false"),
        "SUPPRESS_DUPLICATES":               bp.get("suppress-duplicates",                "false"),
        "HARD_ADMINISTRATIVE_RESET":         bp.get("hard-administrative-reset",          "false"),
        "DISABLE_EBGP_CONNECTED_ROUTE_CHECK":bp.get("disable-ebgp-connected-route-check", "false"),
        "DETERMINISTIC_MED":                 bp.get("deterministic-med",                  "false"),
        "ALWAYS_COMPARE_MED":                bp.get("always-compare-med",                 "false"),
        "GR_PRESERVE_FW_STATE":              bp.get("graceful-restart-preserve-fw-state", "false"),
        "GR_NOTIFICATION":                   bp.get("graceful-restart-notification",      "false"),
        # Integer attrs (0 = not set)
        "MAXIMUM_PATHS_ECMP":      bp.get("maximum-paths-ecmp",                    "0"),
        "GR_SELECT_DEFER_TIME":    bp.get("graceful-restart-select-defer-time",    "0"),
        "GR_RIB_STALE_TIME":       bp.get("graceful-restart-rib-stale-time",       "0"),
        "GR_RESTART_TIME":         bp.get("graceful-restart-restart-time",         "0"),
        "GR_STALEPATH_TIME":       bp.get("graceful-restart-stalepath-time",       "0"),
        "LLGR_STALE_TIME":         bp.get("long-lived-graceful-restart-stale-time","0"),
        # Custom C1: maximum-paths
        "MAXIMUM_PATHS":                    bp.get("maximum-paths",                    "0"),
        "MAXIMUM_PATHS_IBGP":               bp.get("maximum-paths-ibgp",               "0"),
        "MAXIMUM_PATHS_EQUAL_CLUSTER":      bp.get("maximum-paths-equal-cluster-length","false"),
        # Custom C2: distance-bgp
        "DISTANCE_BGP_EXTERNAL": bp.get("distance-bgp-external", "0"),
        "DISTANCE_BGP_INTERNAL": bp.get("distance-bgp-internal", "0"),
        "DISTANCE_BGP_LOCAL":    bp.get("distance-bgp-local",    "0"),
        # Custom C3: dampening
        "DAMPENING":          "true" if damp_list else "false",
        "DAMPENING_PENALTY":  damp.get("penalty",  "0"),
        "DAMPENING_REUSE":    damp.get("reuse",    "0"),
        "DAMPENING_SUPPRESS": damp.get("suppress", "0"),
        "DAMPENING_DURATION": damp.get("duration", "0"),
        # Additional global booleans
        "FAST_EXTERNAL_FAILOVER":               bp.get("fast-external-failover",              "false"),
        "DEFAULT_IPV4_UNICAST":                 bp.get("default-ipv4-unicast",                "false"),
        "DEFAULT_IPV4_MULTICAST":               bp.get("default-ipv4-multicast",              "false"),
        "DEFAULT_IPV4_VPN":                     bp.get("default-ipv4-vpn",                    "false"),
        "DEFAULT_IPV4_FLOWSPEC":                bp.get("default-ipv4-flowspec",               "false"),
        "DEFAULT_IPV6_UNICAST":                 bp.get("default-ipv6-unicast",                "false"),
        "DEFAULT_IPV6_MULTICAST":               bp.get("default-ipv6-multicast",              "false"),
        "DEFAULT_IPV6_VPN":                     bp.get("default-ipv6-vpn",                    "false"),
        "DEFAULT_IPV6_FLOWSPEC":                bp.get("default-ipv6-flowspec",               "false"),
        "DEFAULT_L2VPN_EVPN":                   bp.get("default-l2vpn-evpn",                  "false"),
        "DEFAULT_SHOW_HOSTNAME":                bp.get("default-show-hostname",               "false"),
        "DEFAULT_SHOW_NEXTHOP_HOSTNAME":        bp.get("default-show-nexthop-hostname",       "false"),
        "DEFAULT_DYNAMIC_CAPABILITY":           bp.get("default-dynamic-capability",          "false"),
        "DEFAULT_SOFTWARE_VERSION_CAPABILITY":  bp.get("default-software-version-capability", "false"),
        "ROUTE_REFLECTOR_ALLOW_OUTBOUND":       bp.get("route-reflector-allow-outbound-policy","false"),
        # Additional global integers
        "DEFAULT_ORIGINATE_TIMER":    bp.get("default-originate-timer",    "0"),
        "MINIMUM_HOLDTIME":           bp.get("minimum-holdtime",           "0"),
        "TCP_KEEPALIVE_IDLE":         bp.get("tcp-keepalive-idle",         "0"),
        "TCP_KEEPALIVE_INTERVAL":     bp.get("tcp-keepalive-interval",     "0"),
        "TCP_KEEPALIVE_PROBES":       bp.get("tcp-keepalive-probes",       "0"),
        # Network import check + update-delay
        "NETWORK_IMPORT_CHECK":      bp.get("network-import-check",      "false"),
        "UPDATE_DELAY":              bp.get("update-delay",              "0"),
        "UPDATE_DELAY_WAIT":         bp.get("update-delay-wait",         "0"),
    }


def run(data):
    vrf_name = data["instance_name"]
    attrs    = data["attrs"]
    children = data.get("children") or {}

    objects = []

    # --- Interface name → kernel device name map ---
    # Used to resolve interface neighbors to their kernel device name.
    iface_to_device = {
        ifc["instance_name"]: ifc.get("attrs", {}).get("device", ifc["instance_name"])
        for ifc in children.get("interface", [])
    }

    # --- RtrVrf object ---
    obj_attrs = {
        "TYPE":     "RtrVrf",
        "NAME":     "vrf_" + vrf_name,
        "SHUTDOWN": attrs.get("shutdown", "false"),
    }
    if "table" in attrs:
        obj_attrs["TABLE"] = attrs["table"]
    if "arp-table-size" in attrs:
        obj_attrs["ARP_TABLE_SIZE"] = attrs["arp-table-size"]
    objects.append({
        "section": f"object.vrf-{vrf_name}",
        "attrs":   obj_attrs,
    })

    # --- RtrBgp objects for bgp children ---
    # Resolve sibling ASN for bgp-vrf/bgp-view (inherit from the bgp instance)
    bgp_children = children.get("bgp", [])
    sibling_asn  = bgp_children[0]["instance_name"] if bgp_children else ""

    for bgp_node in bgp_children:
        asn = bgp_node["instance_name"]
        a   = bgp_node.get("attrs", {})
        bgp_type = "main" if vrf_name == "default" else "vrf-kernel"
        obj_a = {
            "TYPE":      "RtrBgp",
            "NAME":      f"bgp_{vrf_name}_{asn}",
            "BGP_TYPE":  bgp_type,
            "ASN":       asn,
            "VRF":       vrf_name,
            "VIEW":      "",
            "ROUTER_ID": a.get("router-id", "0.0.0.0"),
            "SHUTDOWN":  a.get("shutdown",  "true"),
        }
        obj_a.update(_extract_bgp_params(bgp_node))
        _add_neighbor_keys(obj_a, bgp_node, iface_to_device)
        objects.append({
            "section": f"object.bgp-{vrf_name}-{asn}",
            "attrs": obj_a,
        })

    for bgp_vrf_node in children.get("bgp-vrf", []):
        name = bgp_vrf_node["instance_name"]
        a    = bgp_vrf_node.get("attrs", {})
        obj_a = {
            "TYPE":      "RtrBgp",
            "NAME":      f"bgp_vrf_{vrf_name}_{name}",
            "BGP_TYPE":  "vrf-bgp",
            "ASN":       sibling_asn,
            "VRF":       name,
            "VIEW":      "",
            "ROUTER_ID": a.get("router-id", "0.0.0.0"),
            "SHUTDOWN":  a.get("shutdown",  "true"),
        }
        obj_a.update(_extract_bgp_params(bgp_vrf_node))
        _add_neighbor_keys(obj_a, bgp_vrf_node, iface_to_device)
        objects.append({
            "section": f"object.bgp-vrf-{vrf_name}-{name}",
            "attrs": obj_a,
        })

    for bgp_view_node in children.get("bgp-view", []):
        name = bgp_view_node["instance_name"]
        a    = bgp_view_node.get("attrs", {})
        obj_a = {
            "TYPE":      "RtrBgp",
            "NAME":      f"bgp_view_{vrf_name}_{name}",
            "BGP_TYPE":  "view",
            "ASN":       sibling_asn,
            "VRF":       "",
            "VIEW":      name,
            "ROUTER_ID": a.get("router-id", "0.0.0.0"),
            "SHUTDOWN":  a.get("shutdown",  "true"),
        }
        obj_a.update(_extract_bgp_params(bgp_view_node))
        _add_neighbor_keys(obj_a, bgp_view_node, iface_to_device)
        objects.append({
            "section": f"object.bgp-view-{vrf_name}-{name}",
            "attrs": obj_a,
        })

    return objects
