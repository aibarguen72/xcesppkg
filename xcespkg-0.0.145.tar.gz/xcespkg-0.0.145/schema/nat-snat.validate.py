#!/usr/bin/env python3
# nat-snat.validate.py — XCESP-ON-RTR
#
# Validates cross-attribute constraints for a nat-snat rule.
# Invoked by validateHooks() as:
#   python3 nat-snat.validate.py nat-snat <rulename>
# Full config text is provided on stdin.
# Any line printed to stdout is treated as a validation error.

import sys
import re
import ipaddress

node_type = sys.argv[1]   # "nat-snat"
instance  = sys.argv[2]   # rule name
config    = sys.stdin.read()


# --------------------------------------------------------------------------
# Extract the attribute block for the named nat-snat instance
# --------------------------------------------------------------------------
def extract_attrs(config_text, rule_name):
    """Return a dict of attr -> value for the first nat-snat <rule_name> block."""
    lines  = config_text.splitlines()
    in_block = False
    block_indent = None
    attrs = {}
    i = 0
    while i < len(lines):
        line = lines[i]
        if not in_block:
            m = re.match(r'^(\s*)nat-snat\s+(\S+)', line)
            if m and m.group(2) == rule_name:
                in_block     = True
                block_indent = m.group(1) + '  '  # one level deeper
        else:
            # Closing marker: same indent as nat-snat line followed by '!'
            if re.match(r'^\s*!\s*$', line):
                break
            m = re.match(r'^' + re.escape(block_indent) + r'(\S+)\s+(.*?)\s*$', line)
            if m:
                attrs[m.group(1)] = m.group(2)
        i += 1
    return attrs


attrs = extract_attrs(config, instance)
if not attrs:
    # No attributes found — mandatory attrs missing, schema will catch it
    sys.exit(0)

errors = []


# --------------------------------------------------------------------------
# Helper: validate a port-range string "X" or "X:Y"
# Returns (lo, hi) on success, raises ValueError on failure.
# --------------------------------------------------------------------------
def parse_port_range(val):
    parts = val.split(':')
    if len(parts) == 1:
        p = int(parts[0])
        if not (1 <= p <= 65535):
            raise ValueError(f"port {p} out of range 1-65535")
        return p, p
    elif len(parts) == 2:
        lo, hi = int(parts[0]), int(parts[1])
        if not (1 <= lo <= 65535 and 1 <= hi <= 65535):
            raise ValueError(f"port values must be 1-65535")
        if lo >= hi:
            raise ValueError(f"port range low ({lo}) must be less than high ({hi})")
        return lo, hi
    else:
        raise ValueError(f"invalid port-range format '{val}'")


PORT_RANGE_ATTRS = [
    'match-src-tcp-port', 'match-src-udp-port',
    'match-dst-tcp-port', 'match-dst-udp-port',
    'snat-tcp-port', 'snat-udp-port',
]

for attr in PORT_RANGE_ATTRS:
    val = attrs.get(attr, '')
    if val:
        try:
            parse_port_range(val)
        except ValueError as e:
            errors.append(f"{attr} '{val}': {e}")


# --------------------------------------------------------------------------
# Check: IP family consistency
# --------------------------------------------------------------------------
def addr_family(addr):
    """Return 4 or 6 based on address string."""
    bare = addr.split('/')[0]
    try:
        return ipaddress.ip_address(bare).version
    except ValueError:
        return None


src_fam  = addr_family(attrs.get('match-src-address', ''))
dst_fam  = addr_family(attrs.get('match-dst-address', '')) if attrs.get('match-dst-address') else None
snat_fam = addr_family(attrs.get('snat-address', ''))

if src_fam and snat_fam and src_fam != snat_fam:
    errors.append(
        f"match-src-address (IPv{src_fam}) and snat-address (IPv{snat_fam}) "
        f"must be the same IP family"
    )
if src_fam and dst_fam and src_fam != dst_fam:
    errors.append(
        f"match-src-address (IPv{src_fam}) and match-dst-address (IPv{dst_fam}) "
        f"must be the same IP family"
    )


# --------------------------------------------------------------------------
# Determine translation mode: 1:1 vs PAT
# --------------------------------------------------------------------------
src_addr   = attrs.get('match-src-address', '')
snat_tcp   = attrs.get('snat-tcp-port', '')
snat_udp   = attrs.get('snat-udp-port', '')

is_host = False
if src_addr:
    if '/' not in src_addr:
        is_host = True
    else:
        prefix = int(src_addr.split('/')[1])
        max_prefix = 128 if (src_fam == 6) else 32
        is_host = (prefix == max_prefix)

is_1to1 = is_host and not snat_tcp and not snat_udp

# --------------------------------------------------------------------------
# 1:1 mode checks
# --------------------------------------------------------------------------
if is_1to1:
    has_tcp_match = bool(attrs.get('match-src-tcp-port') or attrs.get('match-dst-tcp-port'))
    has_udp_match = bool(attrs.get('match-src-udp-port') or attrs.get('match-dst-udp-port'))
    if has_tcp_match and has_udp_match:
        errors.append(
            "1:1 SNAT mode: cannot mix TCP and UDP port match filters in the same rule; "
            "use separate nat-snat rules for TCP and UDP"
        )

# --------------------------------------------------------------------------
# PAT mode checks
# --------------------------------------------------------------------------
else:
    if snat_tcp and snat_udp:
        errors.append(
            "PAT SNAT mode: snat-tcp-port and snat-udp-port cannot both be set; "
            "use separate nat-snat rules for TCP and UDP, or omit both to cover TCP+UDP+ICMP"
        )
    has_tcp_match = bool(attrs.get('match-src-tcp-port') or attrs.get('match-dst-tcp-port'))
    has_udp_match = bool(attrs.get('match-src-udp-port') or attrs.get('match-dst-udp-port'))
    if has_tcp_match and has_udp_match:
        errors.append(
            "PAT SNAT mode: cannot mix TCP and UDP port match filters in the same rule; "
            "use separate nat-snat rules for TCP and UDP"
        )

for err in errors:
    print(f"nat-snat '{instance}': {err}")
