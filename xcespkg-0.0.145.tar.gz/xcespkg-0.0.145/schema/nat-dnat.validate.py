#!/usr/bin/env python3
# nat-dnat.validate.py — XCESP-ON-RTR
#
# Validates cross-attribute constraints for a nat-dnat rule.
# Invoked by validateHooks() as:
#   python3 nat-dnat.validate.py nat-dnat <rulename>
# Full config text is provided on stdin.
# Any line printed to stdout is treated as a validation error.

import sys
import re
import ipaddress

node_type = sys.argv[1]   # "nat-dnat"
instance  = sys.argv[2]   # rule name
config    = sys.stdin.read()


# --------------------------------------------------------------------------
# Extract the attribute block for the named nat-dnat instance
# --------------------------------------------------------------------------
def extract_attrs(config_text, rule_name):
    """Return a dict of attr -> value for the first nat-dnat <rule_name> block."""
    lines    = config_text.splitlines()
    in_block = False
    block_indent = None
    attrs = {}
    i = 0
    while i < len(lines):
        line = lines[i]
        if not in_block:
            m = re.match(r'^(\s*)nat-dnat\s+(\S+)', line)
            if m and m.group(2) == rule_name:
                in_block     = True
                block_indent = m.group(1) + '  '
        else:
            if re.match(r'^\s*!\s*$', line):
                break
            m = re.match(r'^' + re.escape(block_indent) + r'(\S+)\s+(.*?)\s*$', line)
            if m:
                attrs[m.group(1)] = m.group(2)
        i += 1
    return attrs


attrs = extract_attrs(config, instance)
if not attrs:
    sys.exit(0)

errors = []


# --------------------------------------------------------------------------
# Helper: validate a port-range string "X" or "X:Y"
# --------------------------------------------------------------------------
def parse_port_range(val):
    parts = val.split(':')
    if len(parts) == 1:
        p = int(parts[0])
        if not (1 <= p <= 65535):
            raise ValueError(f"port {p} out of range 1-65535")
        return p, p
    elif len(parts) == 2:
        lo, hi = int(parts[0]), int(parts[1])
        if not (1 <= lo <= 65535 and 1 <= hi <= 65535):
            raise ValueError(f"port values must be 1-65535")
        if lo >= hi:
            raise ValueError(f"port range low ({lo}) must be less than high ({hi})")
        return lo, hi
    else:
        raise ValueError(f"invalid port-range format '{val}'")


PORT_RANGE_ATTRS = [
    'match-src-tcp-port', 'match-src-udp-port',
    'match-dst-tcp-port', 'match-dst-udp-port',
]

for attr in PORT_RANGE_ATTRS:
    val = attrs.get(attr, '')
    if val:
        try:
            parse_port_range(val)
        except ValueError as e:
            errors.append(f"{attr} '{val}': {e}")


# --------------------------------------------------------------------------
# Check: IP family consistency
# --------------------------------------------------------------------------
def addr_family(addr):
    bare = addr.split('/')[0]
    try:
        return ipaddress.ip_address(bare).version
    except ValueError:
        return None


dst_fam  = addr_family(attrs.get('match-dst-address', ''))
src_fam  = addr_family(attrs.get('match-src-address', '')) if attrs.get('match-src-address') else None
dnat_fam = addr_family(attrs.get('dnat-address', ''))

if dst_fam and dnat_fam and dst_fam != dnat_fam:
    errors.append(
        f"match-dst-address (IPv{dst_fam}) and dnat-address (IPv{dnat_fam}) "
        f"must be the same IP family"
    )
if dst_fam and src_fam and dst_fam != src_fam:
    errors.append(
        f"match-dst-address (IPv{dst_fam}) and match-src-address (IPv{src_fam}) "
        f"must be the same IP family"
    )


# --------------------------------------------------------------------------
# Check: dnat-tcp-port and dnat-udp-port constraints
# --------------------------------------------------------------------------
dnat_tcp = attrs.get('dnat-tcp-port', '')
dnat_udp = attrs.get('dnat-udp-port', '')

if dnat_tcp and dnat_udp:
    errors.append(
        "dnat-tcp-port and dnat-udp-port cannot both be set; "
        "a DNAT rule is either TCP or UDP port redirect, not both"
    )

if dnat_tcp:
    mdst_tcp = attrs.get('match-dst-tcp-port', '')
    if not mdst_tcp:
        errors.append(
            "dnat-tcp-port requires match-dst-tcp-port to identify the destination port to intercept"
        )
    elif ':' in mdst_tcp:
        errors.append(
            f"match-dst-tcp-port '{mdst_tcp}': must be a single port (not a range) "
            f"when dnat-tcp-port is set"
        )

if dnat_udp:
    mdst_udp = attrs.get('match-dst-udp-port', '')
    if not mdst_udp:
        errors.append(
            "dnat-udp-port requires match-dst-udp-port to identify the destination port to intercept"
        )
    elif ':' in mdst_udp:
        errors.append(
            f"match-dst-udp-port '{mdst_udp}': must be a single port (not a range) "
            f"when dnat-udp-port is set"
        )

for err in errors:
    print(f"nat-dnat '{instance}': {err}")
