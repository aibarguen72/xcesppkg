"""xcesppy.config — Router CLI config text parser, serializer, and merger.

The config text format is the same as xcespcli / xcespconfig::

    nodetype [instance]
      attr1 value1
      attr2 value2
      childtype [child-instance]
        attr value
      !
    !

Rules:
- Blocks are opened by a ``nodetype [instance]`` line and closed by ``!``.
- Attribute lines have exactly two tokens: ``attr value``.
- Nesting is identified by indent depth: a line whose *next non-empty line* is
  at a strictly greater indent is a block header; otherwise it is an attribute.
- Empty lines and leading/trailing whitespace are ignored.

Public API
----------
parse_config(text)     → list[ConfigNode]
serialize_config(nodes) → str
merge_config(base, partial) → str
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List


@dataclass
class ConfigNode:
    """One node in the hierarchical config tree.

    Attributes
    ----------
    node_type : str
        The schema node type (e.g. ``'domain'``, ``'udpbert'``).
    instance : str
        The instance name (e.g. ``'main'``, ``'bert-a'``).  Empty string for
        anonymous (singleton) nodes.
    attrs : dict[str, str]
        Attribute key/value pairs in declaration order.
    children : list[ConfigNode]
        Child nodes in declaration order.
    """
    node_type: str
    instance:  str
    attrs:     dict  = field(default_factory=dict)
    children:  List['ConfigNode'] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------

def parse_config(text: str) -> List[ConfigNode]:
    """Parse router CLI config text into a list of top-level ConfigNode objects.

    Parameters
    ----------
    text : str
        Config text in xcespconfig / xcespcli format.

    Returns
    -------
    list[ConfigNode]
        Top-level nodes (each may have children).

    Notes
    -----
    Disambiguation rule: a line at indent *d* is a block header if:

    - the next non-empty line is at an indent *strictly greater* than *d*
      (the block has children), **or**
    - the next non-empty line is ``!`` at indent *d* (empty block with no
      children, e.g. ``address 10.0.0.1/24\\n!``).

    Otherwise the line is an attribute (key / optional-value pair).
    """
    # Tokenize: list of (indent, token_list) for every non-empty line
    lines: list[tuple[int, list[str]]] = []
    for line in text.splitlines():
        stripped = line.strip()
        if stripped:
            indent = len(line) - len(line.lstrip())
            lines.append((indent, stripped.split()))

    result: List[ConfigNode] = []
    stack:  list[ConfigNode] = []   # nodes currently being built (innermost last)

    for idx, (indent, tokens) in enumerate(lines):
        # '!' closes the innermost open block
        if tokens == ['!']:
            if stack:
                node = stack.pop()
                if stack:
                    stack[-1].children.append(node)
                else:
                    result.append(node)
            continue

        # Peek at next non-empty line to distinguish attr vs block header
        next_indent = lines[idx + 1][0] if idx + 1 < len(lines) else -1
        next_tokens = lines[idx + 1][1] if idx + 1 < len(lines) else []

        # Block header when next line is deeper, OR when next line is '!' at
        # the same indent (empty block, e.g. "address 10.0.0.1/24\n!")
        is_block = (next_indent > indent) or \
                   (next_tokens == ['!'] and next_indent == indent)

        if is_block:
            # Block header → push a new node onto the stack
            node_type = tokens[0]
            instance  = ' '.join(tokens[1:]) if len(tokens) > 1 else ''
            stack.append(ConfigNode(node_type, instance))
        else:
            # Attribute: key / optional-value pair
            if stack:
                key = tokens[0]
                val = ' '.join(tokens[1:]) if len(tokens) > 1 else ''
                stack[-1].attrs[key] = val
            # Top-level attributes (outside any block) are silently ignored —
            # they should not appear in valid xcespconfig output.

    return result


# ---------------------------------------------------------------------------
# Serializer
# ---------------------------------------------------------------------------

def _serialize_nodes(nodes: List[ConfigNode], depth: int) -> list[str]:
    lines: list[str] = []
    prefix = '  ' * depth
    for node in nodes:
        header = node.node_type + (' ' + node.instance if node.instance else '')
        lines.append(prefix + header)
        for key, val in node.attrs.items():
            lines.append(prefix + '  ' + key + (' ' + val if val else ''))
        lines.extend(_serialize_nodes(node.children, depth + 1))
        lines.append(prefix + '!')
    return lines


def serialize_config(nodes: List[ConfigNode]) -> str:
    """Serialize a list of ConfigNode objects back to router CLI text.

    Parameters
    ----------
    nodes : list[ConfigNode]
        Top-level nodes to serialize.

    Returns
    -------
    str
        Config text with 2-space indentation per nesting level, each block
        closed by ``!``, followed by a trailing newline.
    """
    if not nodes:
        return ''
    return '\n'.join(_serialize_nodes(nodes, 0)) + '\n'


# ---------------------------------------------------------------------------
# Merger
# ---------------------------------------------------------------------------

def _deep_copy(node: ConfigNode) -> ConfigNode:
    return ConfigNode(
        node.node_type,
        node.instance,
        dict(node.attrs),
        [_deep_copy(c) for c in node.children],
    )


def _merge_lists(base: List[ConfigNode],
                 partial: List[ConfigNode]) -> List[ConfigNode]:
    result = [_deep_copy(n) for n in base]
    for p in partial:
        match = next(
            (i for i, b in enumerate(result)
             if b.node_type == p.node_type and b.instance == p.instance),
            None,
        )
        if match is not None:
            b = result[match]
            merged_attrs    = {**b.attrs, **p.attrs}
            merged_children = _merge_lists(b.children, p.children)
            result[match] = ConfigNode(b.node_type, b.instance,
                                       merged_attrs, merged_children)
        else:
            result.append(_deep_copy(p))
    return result


def merge_config(base_text: str, partial_text: str) -> str:
    """Deep-merge *partial_text* into *base_text* and return the merged config.

    Nodes are matched by ``(node_type, instance)``.

    - Attrs in *partial* overwrite the same attrs in *base*.
    - Children in *partial* are recursively merged into *base* children.
    - Nodes present in *partial* but absent in *base* are appended.
    - Nodes present in *base* but absent in *partial* are kept unchanged.

    Parameters
    ----------
    base_text : str
        Current running config (router CLI text).
    partial_text : str
        Partial config to merge in (router CLI text).

    Returns
    -------
    str
        Merged config in router CLI text format.

    Example
    -------
    ::

        current = cli.get_config()
        merged  = merge_config(current, \"""
        domain main
          udpbert new-node
            src-port 9000
            dst-ip 127.0.0.1
            dst-port 9001
          !
        !
        \""")
        cli.put_config(merged)
    """
    return serialize_config(
        _merge_lists(parse_config(base_text), parse_config(partial_text))
    )
