"""xcesppy — Python API library for XCESP functional testing.

Connects to xcespserver via the existing xcespcli TCP protocol.
No new server-side component is required.

Basic usage::

    import xcesppy

    with xcesppy.XCespClient('127.0.0.1', 9900) as cli:
        cli.merge_config(\"\"\"
    domain test
      udpbert bert-a
        src-port 7000
        dst-ip 127.0.0.1
        dst-port 7001
      !
    !
    \"\"\")
        status = cli.get_status('domain/test')
        print(status)
"""

from .client import XCespClient, XCespError
from . import config

__all__ = ['XCespClient', 'XCespError', 'config']
