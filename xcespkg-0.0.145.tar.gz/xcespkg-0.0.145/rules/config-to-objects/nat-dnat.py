#!/usr/bin/env python3
"""
config-to-objects/nat-dnat.py — XCESP-ON-RTR
Maps a 'nat-dnat' config node to one RtrNatDnat xcespproc object.

Path hierarchy: router/<ns>/vrf/<vrf>/nat/<nat>/nat-dnat/<rulename>
xcespmap only passes the direct parent (nat) in data["parent"], so NS and
VRF are found by searching the full config tree.
"""

NEEDS_FULL_CONFIG = True


def _resolve_iface(iface_name, vrf_node):
    """Resolve an interface instance name to its Linux device name."""
    if not iface_name:
        return ""
    for iface in vrf_node.get("children", {}).get("interface", []):
        if iface["instance_name"] == iface_name:
            return iface["attrs"].get("device", iface_name)
    return iface_name   # fallback: use name as-is


def run(data):
    rule  = data["instance_name"]
    attrs = data["attrs"]

    # Locate NS and VRF: xcespmap provides only the immediate parent (nat),
    # so we search the full config for the router/vrf that contains this rule.
    ns, vrf = "", "default"
    vrf_node_found = {}
    for rtr in data.get("config", {}).get("router", []):
        found = False
        for vrf_node in rtr.get("children", {}).get("vrf", []):
            for nat_node in vrf_node.get("children", {}).get("nat", []):
                for dnat in nat_node.get("children", {}).get("nat-dnat", []):
                    if dnat.get("instance_name") == rule and \
                            dnat.get("attrs", {}) == attrs:
                        ns  = rtr.get("instance_name", "")
                        vrf = vrf_node.get("instance_name", "default")
                        vrf_node_found = vrf_node
                        found = True
                        break
                if found:
                    break
            if found:
                break
        if found:
            break

    if not ns:
        return []

    # Resolve ingress interface name to Linux device name
    ingress_dev = _resolve_iface(
        attrs.get("match-ingress-interface", ""), vrf_node_found)

    obj_attrs = {
        "TYPE":  "RtrNatDnat",
        "NAME":  f"natdnat_{ns}_{vrf}_{rule}",
        "NS":    ns,
        "VRF":   vrf,
        "RULE":  rule,
        # Mandatory
        "MATCH_DST_ADDR": attrs["match-dst-address"],
        "DNAT_ADDR":      attrs["dnat-address"],
        # Optional — empty string when absent
        "MATCH_SRC_ADDR":      attrs.get("match-src-address",  ""),
        "MATCH_SRC_TCP_PORT":  attrs.get("match-src-tcp-port", ""),
        "MATCH_SRC_UDP_PORT":  attrs.get("match-src-udp-port", ""),
        "MATCH_DST_TCP_PORT":  attrs.get("match-dst-tcp-port", ""),
        "MATCH_DST_UDP_PORT":  attrs.get("match-dst-udp-port", ""),
        "DNAT_TCP_PORT":       attrs.get("dnat-tcp-port",      ""),
        "DNAT_UDP_PORT":       attrs.get("dnat-udp-port",      ""),
        # Interface matching (resolved to Linux device name)
        "MATCH_INGRESS_DEV": ingress_dev,
    }

    return [
        {
            "section": f"object.natdnat-{ns}-{vrf}-{rule}",
            "attrs":   obj_attrs,
        }
    ]
