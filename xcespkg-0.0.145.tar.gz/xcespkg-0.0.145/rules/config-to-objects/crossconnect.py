"""
config-to-objects/crossconnect.py — XCESP-ON-XC
Maps a 'crossconnect' config node to xcespproc INI objects.

TODO: implement when CrossConnectPObj is ready.
"""


def run(data):
    """
    data: dict representation of a ConfigNode
        {
          "node_type": "crossconnect",
          "instance_name": "<name>",
          "attrs": { "type": "static", "from-port": "...", "to-port": "..." },
          "children": {}
        }
    """
    return []
