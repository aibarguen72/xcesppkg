#!/usr/bin/env python3
# Maps one 'udpbert' config node to two ObjectIniDef entries:
#   1. UdpTester  (ROLE_MASTER) — UDP transport layer
#   2. PktBert    (ROLE_SLAVE, pull-mode) — PRBS generator/verifier

def run(data):
    attrs     = data.get('attrs', {})
    instance  = data.get('instance_name', 'bert')
    link_name = instance + '-link'

    # Clamp to nearest valid PRBS degree (7, 11, or 15)
    prbs_raw  = int(attrs.get('prbs-type', 7))
    prbs_type = min([7, 11, 15], key=lambda v: abs(v - prbs_raw))

    udp_obj = {
        "section": f"object.{instance}-udp",
        "attrs": {
            "TYPE":        "UdpTester",
            "NAME":        instance + "-udp",
            "INTERVAL_MS": attrs.get('interval-ms', '1000'),
            "PACKET_SIZE": attrs.get('packet-size', '64'),
            "SRC_IP":      attrs.get('src-ip', '127.0.0.1'),
            "SRC_PORT":    attrs.get('src-port', '0'),
            "DST_IP":      attrs.get('dst-ip', '127.0.0.1'),
            "DST_PORT":    attrs.get('dst-port', '0'),
            "LINK":        link_name,
        }
    }

    bert_obj = {
        "section": f"object.{instance}-bert",
        "attrs": {
            "TYPE":        "PktBert",
            "NAME":        instance + "-bert",
            "INTERVAL_MS": "0",          # pull-mode: UdpTester drives the packet cadence
            "PACKET_SIZE": attrs.get('packet-size', '64'),
            "PRBS_TYPE":   str(prbs_type),
            "LINK":        link_name,
        }
    }

    return [udp_obj, bert_obj]
