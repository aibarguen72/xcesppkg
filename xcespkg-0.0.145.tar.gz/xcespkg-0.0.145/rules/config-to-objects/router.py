#!/usr/bin/env python3
"""
config-to-objects/router.py — XCESP-ON-RTR
Maps a 'router' config node to one RtrRouter xcespproc object, and optionally
to one RtrFrr object when a 'dynamic-routing' child block is present.

Also emits RtrAcl objects for each bgp-as-path-acl, bgp-community-list-standard,
bgp-community-list-expanded, and prefix-list child block.

The router instance name becomes the Linux network namespace name.
"default" is the host namespace (no namespace is created/managed).
"""

# Map of (schema child type → ACL_TYPE INI value)
_LIST_TYPES = {
    "bgp-as-path-acl":              "as-path-acl",
    "bgp-community-list-standard":  "community-list-standard",
    "bgp-community-list-expanded":  "community-list-expanded",
    "prefix-list":                  "prefix-list",
    "access-list":                  "access-list",
    "access-list-extended":         "access-list-extended",
}


# ---------------------------------------------------------------------------
# swanctl.conf rendering helpers (ipsec child node → SWAN_LINE_* content)
# ---------------------------------------------------------------------------

def _sw_bool(val):
    if isinstance(val, str):
        return "yes" if val.lower() in ("true", "yes", "1") else "no"
    return "yes" if val else "no"

def _sw_any(val):
    if not val or val == "*":
        return "%any"
    return val

def _sw_proposals(node):
    if not node:
        return ""
    algos = [a["instance_name"] for a in (node.get("children") or {}).get("algorithm", [])]
    return ",".join(algos)

def _sw_ts(node):
    if not node:
        return ""
    matches = [m["instance_name"] for m in (node.get("children") or {}).get("match", [])]
    return ",".join(matches)

_CONN_ATTR_MAP = [
    ("version",          "version"),
    ("local-port",       "local_port"),
    ("remote-port",      "remote_port"),
    ("virtual-address",  "vips"),
    ("pools",            "pools"),
    ("dscp",             "dscp"),
    ("dpd-delay",        "dpd_delay"),
    ("dpd-timeout",      "dpd_timeout"),
    ("keying-tries",     "keying_tries"),
    ("reauth-time",      "reauth_time"),
    ("rekey-time",       "rekey_time"),
    ("over-time",        "over_time"),
    ("rand-time",        "rand_time"),
    ("ocsp",             "ocsp"),
    ("fragmentation",    "fragmentation"),
    ("childless",        "childless"),
    ("send-cert",        "send_cert"),
    ("unique",           "unique"),
]
_CONN_BOOL_MAP = [
    ("aggressive",        "aggressive"),
    ("encapsulation",     "encap"),
    ("mobike",            "mobike"),
    ("send-cert-request", "send_certreq"),
]
_LOCAL_ATTR_MAP = [
    ("auth",     "auth"),
    ("eap-id",   "eap_id"),
    ("aaa-id",   "aaa_id"),
    ("xauth-id", "xauth_id"),
]
_REMOTE_EXTRA_MAP = [
    ("ca-id",       "ca_id"),
    ("groups",      "groups"),
    ("cert-policy", "cert_policy"),
    ("revocation",  "revocation"),
]
_CHILD_ATTR_MAP = [
    ("rekey-time",     "rekey_time"),
    ("life-time",      "life_time"),
    ("rand-time",      "rand_time"),
    ("rekey-bytes",    "rekey_bytes"),
    ("life-bytes",     "life_bytes"),
    ("rand-bytes",     "rand_bytes"),
    ("rekey-packets",  "rekey_packets"),
    ("life-packets",   "life_packets"),
    ("rand-packets",   "rand_packets"),
    ("inactivity",     "inactivity"),
    ("replay-window",  "replay_window"),
    ("mode",           "mode"),
    ("dpd-action",     "dpd_action"),
    ("close-action",   "close_action"),
    ("per-cpu-sas",    "per_cpu_sas"),
    ("hw-offload",     "hw_offload"),
    ("copy-dscp",      "copy_dscp"),
]
_CHILD_BOOL_MAP = [
    ("policies",         "policies"),
    ("policies-fwd-out", "policies_fwd_out"),
    ("ipcomp",           "ipcomp"),
    ("copy-df",          "copy_df"),
    ("copy-ecn",         "copy_ecn"),
    ("icmp-error",       "icmp"),
]


def _sw_render_auth_round(kind, node):
    rid = node["instance_name"]
    a   = node.get("attrs", {})
    out = [f"    {kind}-{rid} {{"]
    for xk, sk in _LOCAL_ATTR_MAP:
        v = a.get(xk, "")
        if v:
            out.append(f"      {sk} = {v}")
    id_val = a.get("id", "")
    if id_val:
        out.append(f"      id = {_sw_any(id_val)}")
    if kind == "remote":
        for xk, sk in _REMOTE_EXTRA_MAP:
            v = a.get(xk, "")
            if v:
                out.append(f"      {sk} = {v}")
    out.append("    }")
    return out


def _sw_render_child(node):
    name = node["instance_name"]
    a    = node.get("attrs", {})
    ch   = node.get("children") or {}
    out  = [f"      {name} {{"]
    for lst_key, sw_key in [("esp-proposals", "esp_proposals"),
                             ("ah-proposals",  "ah_proposals")]:
        nodes = ch.get(lst_key, [])
        if nodes:
            s = _sw_proposals(nodes[0])
            if s:
                out.append(f"        {sw_key} = {s}")
    for lst_key, sw_key in [("local-ts", "local_ts"), ("remote-ts", "remote_ts")]:
        nodes = ch.get(lst_key, [])
        if nodes:
            s = _sw_ts(nodes[0])
            if s:
                out.append(f"        {sw_key} = {s}")
    for xk, sk in _CHILD_ATTR_MAP:
        v = a.get(xk, "")
        if v:
            out.append(f"        {sk} = {v}")
    sa = a.get("start-action", "")
    if sa:
        out.append(f"        start_action = {'trap|start' if sa == 'trapstart' else sa}")
    for xk, sk in _CHILD_BOOL_MAP:
        v = a.get(xk, "")
        if v != "":
            out.append(f"        {sk} = {_sw_bool(v)}")
    out.append("      }")
    return out


def _sw_render_connection(conn):
    name = conn["instance_name"]
    a    = conn.get("attrs", {})
    ch   = conn.get("children") or {}
    out  = [f"  {name} {{"]
    la = a.get("local-address", "")
    if la:
        out.append(f"    local_addrs = {_sw_any(la)}")
    ra = a.get("remote-address", "")
    if ra:
        out.append(f"    remote_addrs = {_sw_any(ra)}")
    for xk, sk in _CONN_ATTR_MAP:
        v = a.get(xk, "")
        if v:
            out.append(f"    {sk} = {v}")
    for xk, sk in _CONN_BOOL_MAP:
        v = a.get(xk, "")
        if v != "":
            out.append(f"    {sk} = {_sw_bool(v)}")
    props = ch.get("proposals", [])
    if props:
        s = _sw_proposals(props[0])
        if s:
            out.append(f"    proposals = {s}")
    for loc in ch.get("local", []):
        out += _sw_render_auth_round("local", loc)
    for rem in ch.get("remote", []):
        out += _sw_render_auth_round("remote", rem)
    child_list = ch.get("children", [])
    if child_list:
        out.append("    children {")
        for child in child_list:
            out += _sw_render_child(child)
        out.append("    }")
    out.append("  }")
    return out


def _sw_render_secret(secret):
    name  = secret["instance_name"]
    a     = secret.get("attrs", {})
    ch    = secret.get("children") or {}
    stype = a.get("type", "ike")
    out   = [f"  {stype}-{name} {{"]
    sec = a.get("secret", "")
    if sec:
        out.append(f"    secret = {sec}")
    for id_node in ch.get("id", []):
        label = id_node["instance_name"]
        match = (id_node.get("attrs") or {}).get("match", "")
        if not match:
            continue
        if label == "*" or match == "*":
            out.append("    id = %any")
        else:
            out.append(f"    id-{label} = {_sw_any(match)}")
    out.append("  }")
    return out


def _sw_render_pool(pool):
    name = pool["instance_name"]
    a    = pool.get("attrs", {})
    out  = [f"  {name} {{"]
    addr = a.get("address", "")
    if addr:
        out.append(f"    addrs = {addr}")
    out.append("  }")
    return out


def _render_swanctl(ipsec_children):
    """Build swanctl.conf lines from ipsec child-node dict."""
    lines = []
    connections = ipsec_children.get("connection", [])
    if connections:
        lines.append("connections {")
        for conn in connections:
            lines += _sw_render_connection(conn)
        lines.append("}")
    secrets = ipsec_children.get("secret", [])
    if secrets:
        lines.append("secrets {")
        for sec in secrets:
            lines += _sw_render_secret(sec)
        lines.append("}")
    pools = ipsec_children.get("pool", [])
    if pools:
        lines.append("pools {")
        for pool in pools:
            lines += _sw_render_pool(pool)
        lines.append("}")
    return lines


def _extract_rules(list_node):
    """Extract ordered permit/deny rules from a list node.

    Returns list of dicts with action, value, seq, ge, le.
    Permits are emitted first (in document order), then denys.
    Use seq attribute to control explicit FRR ordering.
    """
    rules = []
    children = list_node.get("children") or {}
    for action_type in ("acl-permit", "acl-deny"):
        frr_action = action_type.replace("acl-", "")  # "permit" or "deny"
        for rule in children.get(action_type, []):
            a = rule.get("attrs", {})
            rules.append({
                "action": frr_action,
                "value":  rule["instance_name"],
                "seq":    a.get("seq", ""),
                "ge":     a.get("ge", ""),
                "le":     a.get("le", ""),
            })
    return rules


def run(data):
    ns = data["instance_name"]

    objects = [
        {
            "section": f"object.router-{ns}",
            "attrs": {
                "TYPE":           "RtrRouter",
                "NAME":           "router_" + ns,
                "NAMESPACE":       ns,
                "SHUTDOWN":        data["attrs"].get("shutdown",   "false"),
                "FORWARDING":      data["attrs"].get("forwarding", "true"),
                "ROUTER_ID":       data["attrs"].get("router-id",  "0.0.0.0"),
                "MPLS":            "false",
                "MPLS_MAX_LABELS": "1000",
            },
        }
    ]

    # Emit RtrFrr object when dynamic-routing child is present
    dr = (data.get("children") or {}).get("dynamic-routing", [])
    if dr:
        d = dr[0]   # at most one dynamic-routing child per router
        a = d.get("attrs", {})
        objects[0]["attrs"]["MPLS"]            = a.get("mpls",            "false")
        objects[0]["attrs"]["MPLS_MAX_LABELS"] = str(a.get("mpls-max-labels", "1000"))
        objects.append({
            "section": f"object.frr-{ns}",
            "attrs": {
                "TYPE":      "RtrFrr",
                "NAME":      "frr_" + ns,
                "NAMESPACE": ns,
                "SHUTDOWN":  a.get("shutdown", "false"),
                "ROUTER_ID": data["attrs"].get("router-id", "0.0.0.0"),
                "BGP":       a.get("bgp",    "false"),
                "NHRP":      a.get("nhrp",   "false"),
                "OSPF":      a.get("ospf",   "false"),
                "OSPF6":     a.get("ospf6",  "false"),
                "RIP":       a.get("rip",    "false"),
                "RIPNG":     a.get("ripng",  "false"),
                "LDP":       a.get("ldp",    "false"),
                "BABEL":     a.get("babel",  "false"),
                "PIM":       a.get("pim",    "false"),
                "VRRP":      a.get("vrrp",   "false"),
            },
        })

    # Emit RtrStrongswan object when ipsec child is present.
    # SWAN_LINE_* keys for swanctl.conf are rendered here (not in a separate
    # ipsec.py rule) because xcespserver's deploy logic keys on NAME; a
    # separate ObjectIniDef without NAME would be silently ignored.
    ipsec = (data.get("children") or {}).get("ipsec", [])
    if ipsec:
        s  = ipsec[0]
        ia = s.get("attrs", {})
        ic = s.get("children") or {}
        # Collect the first non-wildcard local-address across all connections.
        # This is leaked into the namespace main routing table so charon can bind
        # to the VRF address (which otherwise only exists in the VRF table).
        charon_local_addr = ""
        for conn in (ic.get("connection") or []):
            la = (conn.get("attrs") or {}).get("local-address", "")
            if la and la != "*":
                charon_local_addr = la
                break
        swan_attrs = {
            "TYPE":           "RtrStrongswan",
            "NAME":           "swan_" + ns,
            "NAMESPACE":      ns,
            "SHUTDOWN":       ia.get("shutdown", "false"),
            "CHARON_VRF":     ia.get("vrf", ""),
            "CHARON_LOCAL_ADDR": charon_local_addr,
        }
        # Generate swanctl.conf lines from connection/secret/pool sub-nodes
        swan_lines = _render_swanctl(ic)
        swan_attrs["SWAN_LINE_COUNT"] = str(len(swan_lines))
        for i, line in enumerate(swan_lines):
            swan_attrs[f"SWAN_LINE_{i}"] = line
        objects.append({
            "section": f"object.swan-{ns}",
            "attrs":   swan_attrs,
        })

    # Emit RtrAcl objects for ACL / community-list / prefix-list children
    for schema_type, acl_type in _LIST_TYPES.items():
        for lst in (data.get("children") or {}).get(schema_type, []):
            name  = lst["instance_name"]
            rules = _extract_rules(lst)
            obj_a = {
                "TYPE":       "RtrAcl",
                "NAME":       f"acl_{acl_type}_{ns}_{name}",
                "ACL_TYPE":   acl_type,
                "ACL_NAME":   name,
                "RULE_COUNT": str(len(rules)),
            }
            for i, r in enumerate(rules):
                obj_a[f"RULE_{i}_ACTION"] = r["action"]
                obj_a[f"RULE_{i}_VALUE"]  = r["value"]
                obj_a[f"RULE_{i}_SEQ"]    = r["seq"]
                obj_a[f"RULE_{i}_GE"]     = r["ge"]
                obj_a[f"RULE_{i}_LE"]     = r["le"]
            objects.append({
                "section": f"object.acl-{acl_type}-{ns}-{name}",
                "attrs": obj_a,
            })

    # Emit RtrRouteMap objects for route-map children
    for rmap in (data.get("children") or {}).get("route-map", []):
        rmap_name = rmap["instance_name"]
        rmap_lines = _build_rmap_lines(rmap_name, rmap)
        obj_a = {
            "TYPE":       "RtrRouteMap",
            "NAME":       f"rmap_{ns}_{rmap_name}",
            "RMAP_NAME":  rmap_name,
            "RULE_COUNT": str(len(rmap_lines)),
        }
        for i, line in enumerate(rmap_lines):
            obj_a[f"RULE_{i}"] = line
        objects.append({
            "section": f"object.rmap-{ns}-{rmap_name}",
            "attrs": obj_a,
        })

    return objects


# ---------------------------------------------------------------------------
# Route-map helpers
# ---------------------------------------------------------------------------

# Match attrs: (XCESPCLI attr name, FRR command suffix)
_MATCH_MAP = [
    ("match-ip-address",               "match ip address"),
    ("match-ipv6-address",             "match ipv6 address"),
    ("match-ip-address-prefix-list",   "match ip address prefix-list"),
    ("match-ipv6-address-prefix-list", "match ipv6 address prefix-list"),
    ("match-ip-next-hop-address",      "match ip next-hop address"),
    ("match-ipv6-next-hop-address",    "match ipv6 next-hop address"),
    ("match-ip-next-hop",              "match ip next-hop"),
    ("match-ipv6-next-hop",            "match ipv6 next-hop"),
    ("match-ip-next-hop-prefix-list",  "match ip next-hop prefix-list"),
    ("match-ipv6-next-hop-prefix-list","match ipv6 next-hop prefix-list"),
    ("match-as-path",                  "match as-path"),
    ("match-metric",                   "match metric"),
    ("match-vpn-dataplane",            "match vpn dataplane"),
    ("match-local-preference",         "match local-preference"),
    ("match-source-protocol",          "match source-protocol"),
    ("match-evpn-route-type",          "match evpn route-type"),
    ("match-evpn-vni",                 "match evpn vni"),
    ("match-src-peer-address-ip",      "match src-peer"),
    ("match-src-peer-address-ipv6",    "match src-peer"),
    ("match-src-peer-interface",       "match src-peer"),
    ("match-src-peer-group",           "match src-peer"),
    ("match-peer-address-ip",          "match peer"),
    ("match-peer-address-ipv6",        "match peer"),
    ("match-peer-interface",           "match peer"),
    ("match-peer-group",               "match peer"),
]


def _build_rmap_lines(rmap_name, rmap_node):
    """Build FRR lines for all rules in a route-map. Returns list of strings."""
    lines = []
    children = rmap_node.get("children") or {}
    for action_type in ("rmap-permit", "rmap-deny"):
        frr_action = action_type.replace("rmap-", "")
        for rule in children.get(action_type, []):
            order = rule["instance_name"]
            a = rule.get("attrs", {})
            # Header
            lines.append(f"route-map {rmap_name} {frr_action} {order}")
            # Match
            _emit_rmap_match(lines, a)
            # Set
            _emit_rmap_set(lines, a)
            # Call
            if a.get("call"):
                lines.append(f" call {a['call']}")
            # Exit
            if a.get("on-match-next") in ("true", "True", True):
                lines.append(" on-match next")
            if a.get("on-match-goto"):
                lines.append(f" on-match goto {a['on-match-goto']}")
            if a.get("continue"):
                lines.append(f" continue {a['continue']}")
            # Close stanza
            lines.append("!")
    return lines


def _emit_rmap_match(lines, a):
    """Emit the match line for a route-map rule."""
    # tag special case: 0 = untagged
    tag = a.get("match-tag", "")
    if tag:
        lines.append(f" match tag {'untagged' if tag == '0' else tag}")
        return
    # community special cases
    if a.get("match-community-exact"):
        lines.append(f" match community {a['match-community-exact']} exact-match")
        return
    if a.get("match-community-any"):
        lines.append(f" match community {a['match-community-any']} any")
        return
    # Generic match attrs
    for xcli, frr in _MATCH_MAP:
        val = a.get(xcli, "")
        if val:
            lines.append(f" {frr} {val}")
            return


def _emit_rmap_set(lines, a):
    """Emit set lines for a route-map rule. Multiple set lines can coexist."""
    # tag
    tag = a.get("set-tag", "")
    if tag:
        lines.append(f" set tag {'untagged' if tag == '0' else tag}")
    # ip next-hop (mutually exclusive options)
    if a.get("set-ip-next-hop"):
        lines.append(f" set ip next-hop {a['set-ip-next-hop']}")
    elif a.get("set-ip-next-hop-peer-address") in ("true", "True", True):
        lines.append(" set ip next-hop peer-address")
    elif a.get("set-ip-next-hop-unchanged") in ("true", "True", True):
        lines.append(" set ip next-hop unchanged")
    # ipv6 next-hop
    if a.get("set-ipv6-next-hop-global"):
        lines.append(f" set ipv6 next-hop global {a['set-ipv6-next-hop-global']}")
    if a.get("set-ipv6-next-hop-local"):
        lines.append(f" set ipv6 next-hop local {a['set-ipv6-next-hop-local']}")
    if a.get("set-ipv6-next-hop-peer-address") in ("true", "True", True):
        lines.append(" set ipv6 next-hop peer-address")
    if a.get("set-ipv6-next-hop-prefer-global") in ("true", "True", True):
        lines.append(" set ipv6 next-hop prefer-global")
    # local-preference (mutually exclusive)
    if a.get("set-local-preference"):
        lines.append(f" set local-preference {a['set-local-preference']}")
    elif a.get("set-local-preference-add"):
        lines.append(f" set local-preference +{a['set-local-preference-add']}")
    elif a.get("set-local-preference-sub"):
        lines.append(f" set local-preference -{a['set-local-preference-sub']}")
    # distance, weight
    if a.get("set-distance"):
        lines.append(f" set distance {a['set-distance']}")
    if a.get("set-weight"):
        lines.append(f" set weight {a['set-weight']}")
    # metric (mutually exclusive)
    if a.get("set-metric"):
        lines.append(f" set metric {a['set-metric']}")
    elif a.get("set-metric-add"):
        lines.append(f" set metric +{a['set-metric-add']}")
    elif a.get("set-metric-sub"):
        lines.append(f" set metric -{a['set-metric-sub']}")
    elif a.get("set-metric-value"):
        lines.append(f" set metric {a['set-metric-value']}")
    # min/max metric
    if a.get("set-min-metric"):
        lines.append(f" set min-metric {a['set-min-metric']}")
    if a.get("set-max-metric"):
        lines.append(f" set max-metric {a['set-max-metric']}")
    # aigp-metric
    if a.get("set-aigp-metric"):
        lines.append(f" set aigp-metric {a['set-aigp-metric']}")
    elif a.get("set-aigp-metric-igp") in ("true", "True", True):
        lines.append(" set aigp-metric igp")
    # as-path
    if a.get("set-as-path-prepend"):
        lines.append(f" set as-path prepend {a['set-as-path-prepend']}")
    if a.get("set-as-path-exclude"):
        lines.append(f" set as-path exclude {a['set-as-path-exclude']}")
    # community, origin, table
    if a.get("set-community"):
        lines.append(f" set community {a['set-community']}")
    if a.get("set-origin"):
        lines.append(f" set origin {a['set-origin']}")
    if a.get("set-table"):
        lines.append(f" set table {a['set-table']}")
    if a.get("set-sr-te-color"):
        lines.append(f" set sr-te color {a['set-sr-te-color']}")
    if a.get("set-l3vpn-next-hop-encapsulation-gre") in ("true", "True", True):
        lines.append(" set l3vpn next-hop encapsulation gre")
