"""
config-to-objects/pseudowire.py — XCESP-ON-PW
Maps a 'pseudowire' config node to xcespproc INI objects.

TODO: implement when CesoPsnPObj / SaTopPObj are ready.
      Return one or more dicts with 'section' and 'attrs' keys.
"""


def run(data):
    """
    data: dict representation of a ConfigNode
        {
          "node_type": "pseudowire",
          "instance_name": "<name>",
          "attrs": { "mode": "cesopsn", "local-port": "...", ... },
          "children": {}
        }

    Return a list of object definitions, e.g.:
        [{"section": "object.pw-<name>",
          "attrs": {"TYPE": "CesoPsn", "NAME": "<name>", ...}}]
    """
    return []
