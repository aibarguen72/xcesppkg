#!/usr/bin/env python3
# config-to-objects/udptester.py
# Maps one 'udptester' config node to one UdpTester ObjectIniDef.
#
# Called by xcespmap worker; must export run(data: dict) -> list.


def run(data):
    attrs = data.get('attrs', {})
    return [
        {
            "section": f"object.{data.get('instance_name', '1')}",
            "attrs": {
                "TYPE":        "UdpTester",
                "NAME":        data.get('instance_name', ''),
                "INTERVAL_MS": attrs.get('interval-ms', '1000'),
                "PACKET_SIZE": attrs.get('packet-size', '64'),
                "SRC_IP":      attrs.get('src-ip', '127.0.0.1'),
                "SRC_PORT":    attrs.get('src-port', '0'),
                "DST_IP":      attrs.get('dst-ip', '127.0.0.1'),
                "DST_PORT":    attrs.get('dst-port', '0'),
            }
        }
    ]
