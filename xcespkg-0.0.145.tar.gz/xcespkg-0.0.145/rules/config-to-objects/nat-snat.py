#!/usr/bin/env python3
"""
config-to-objects/nat-snat.py — XCESP-ON-RTR
Maps a 'nat-snat' config node to one RtrNatSnat xcespproc object.

Path hierarchy: router/<ns>/vrf/<vrf>/nat/<nat>/nat-snat/<rulename>
xcespmap only passes the direct parent (nat) in data["parent"], so NS and
VRF are found by searching the full config tree.
"""

import hashlib

NEEDS_FULL_CONFIG = True


def _resolve_iface(iface_name, vrf_node):
    """Resolve an interface instance name to its Linux device name."""
    if not iface_name:
        return ""
    for iface in vrf_node.get("children", {}).get("interface", []):
        if iface["instance_name"] == iface_name:
            return iface["attrs"].get("device", iface_name)
    return iface_name   # fallback: use name as-is


def run(data):
    rule  = data["instance_name"]
    attrs = data["attrs"]

    # Locate NS and VRF: xcespmap provides only the immediate parent (nat),
    # so we search the full config for the router/vrf that contains this rule.
    ns, vrf = "", "default"
    vrf_node_found = {}
    for rtr in data.get("config", {}).get("router", []):
        found = False
        for vrf_node in rtr.get("children", {}).get("vrf", []):
            for nat_node in vrf_node.get("children", {}).get("nat", []):
                for snat in nat_node.get("children", {}).get("nat-snat", []):
                    if snat.get("instance_name") == rule and \
                            snat.get("attrs", {}) == attrs:
                        ns  = rtr.get("instance_name", "")
                        vrf = vrf_node.get("instance_name", "default")
                        vrf_node_found = vrf_node
                        found = True
                        break
                if found:
                    break
            if found:
                break
        if found:
            break

    if not ns:
        return []

    # Resolve interface names to Linux device names
    ingress_dev = _resolve_iface(
        attrs.get("match-ingress-interface", ""), vrf_node_found)
    egress_dev  = _resolve_iface(
        attrs.get("match-egress-interface",  ""), vrf_node_found)

    # Derive deterministic mark for SNAT ingress (MARK-based workaround for POSTROUTING)
    ingress_mark = ""
    if ingress_dev:
        h = int(hashlib.md5(f"{ns}:{vrf}:{rule}".encode()).hexdigest(), 16)
        ingress_mark = str(h & 0xFFFFF)   # 20-bit decimal

    obj_attrs = {
        "TYPE":  "RtrNatSnat",
        "NAME":  f"natsnat_{ns}_{vrf}_{rule}",
        "NS":    ns,
        "VRF":   vrf,
        "RULE":  rule,
        # Mandatory
        "MATCH_SRC_ADDR": attrs["match-src-address"],
        "SNAT_ADDR":      attrs["snat-address"],
        # Optional — empty string when absent
        "MATCH_DST_ADDR":      attrs.get("match-dst-address",  ""),
        "MATCH_SRC_TCP_PORT":  attrs.get("match-src-tcp-port", ""),
        "MATCH_SRC_UDP_PORT":  attrs.get("match-src-udp-port", ""),
        "MATCH_DST_TCP_PORT":  attrs.get("match-dst-tcp-port", ""),
        "MATCH_DST_UDP_PORT":  attrs.get("match-dst-udp-port", ""),
        "SNAT_TCP_PORT":       attrs.get("snat-tcp-port",      ""),
        "SNAT_UDP_PORT":       attrs.get("snat-udp-port",      ""),
        # Interface matching (resolved to Linux device names)
        "MATCH_INGRESS_DEV": ingress_dev,
        "INGRESS_MARK":      ingress_mark,
        "MATCH_EGRESS_DEV":  egress_dev,
    }

    return [
        {
            "section": f"object.natsnat-{ns}-{vrf}-{rule}",
            "attrs":   obj_attrs,
        }
    ]
