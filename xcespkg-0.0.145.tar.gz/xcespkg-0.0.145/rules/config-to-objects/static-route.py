#!/usr/bin/env python3
"""
config-to-objects/static-route.py — XCESP-ON-RTR
Maps a 'static-route' config node to one RtrStaticRoute xcespproc object.

VRF_TABLE is populated from the parent vrf's 'table' attr when present,
allowing RtrStaticRoutePObj to add the route to the correct routing table.

Route target: either NEXTHOP (gateway IP) or EGRESS (P-P device) must be set.
"""


def run(data):
    attrs    = data["attrs"]
    network  = data["instance_name"]

    # Derive NS and VRF names from the parent chain so that routes in different
    # namespaces or VRFs get unique object names and don't collide.
    parent   = data.get("parent") or {}          # vrf node
    vrf_name = parent.get("instance_name", "")
    gp       = parent.get("parent") or {}        # router node
    ns_name  = gp.get("instance_name", "")

    # Build a unique key that includes namespace and VRF
    suffix = ""
    if ns_name:
        suffix += ns_name + "-"
    if vrf_name and vrf_name != "default":
        suffix += vrf_name + "-"
    # Replace slashes in network (e.g. "10.0.0.0/24" → "10.0.0.0_24") for safe keys
    net_key = network.replace("/", "_")

    obj_attrs = {
        "TYPE":     "RtrStaticRoute",
        "NAME":     "route_" + suffix + net_key,
        "NETWORK":  network,
        "NEXTHOP":  attrs.get("next-hop", ""),
        "EGRESS":   attrs.get("egress",   ""),
        "METRIC":   attrs.get("metric", "1"),
        "SHUTDOWN": attrs.get("shutdown", "false"),
    }

    # Propagate parent VRF table number only when explicitly configured
    vrf_table = parent.get("attrs", {}).get("table", "")
    if vrf_table:
        obj_attrs["VRF_TABLE"] = vrf_table

    return [
        {
            "section": f"object.route-{suffix}{net_key}",
            "attrs": obj_attrs,
        }
    ]
