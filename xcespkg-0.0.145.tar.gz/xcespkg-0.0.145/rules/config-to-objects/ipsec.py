#!/usr/bin/env python3
"""
config-to-objects/ipsec.py — XCESP-ON-RTR
Maps an 'ipsec' config node to SWAN_LINE_* INI keys on the existing
RtrStrongswan xcespproc object emitted by router.py.

The rendered lines form a complete swanctl.conf file that RtrStrongswanPObj
writes to /etc/swanctl/swanctl.conf (default ns) or /etc/swanctl/<ns>/swanctl.conf.

Attribute translation (XCESP → swanctl):
  local-address   → local_addrs     ("*" → "%any")
  remote-address  → remote_addrs    ("*" → "%any")
  virtual-address → vips
  local-port      → local_port
  remote-port     → remote_port
  encapsulation   → encap
  send-cert-request → send_certreq
  send-cert       → send_cert
  keying-tries    → keying_tries
  reauth-time     → reauth_time
  rekey-time      → rekey_time
  over-time       → over_time
  rand-time       → rand_time
  dpd-delay       → dpd_delay
  dpd-timeout     → dpd_timeout
  eap-id          → eap_id
  aaa-id          → aaa_id
  xauth-id        → xauth_id
  ca-id           → ca_id
  cert-policy     → cert_policy
  esp-proposals   → esp_proposals (comma-joined algorithms)
  ah-proposals    → ah_proposals  (comma-joined algorithms)
  local-ts        → local_ts      (comma-joined match strings)
  remote-ts       → remote_ts     (comma-joined match strings)
  policies-fwd-out → policies_fwd_out
  icmp-error      → icmp
  start-action trapstart → start_action = trap|start
  copy-df         → copy_df
  copy-ecn        → copy_ecn
  copy-dscp       → copy_dscp
  per-cpu-sas     → per_cpu_sas
  hw-offload      → hw_offload
  replay-window   → replay_window
  rekey-bytes     → rekey_bytes
  life-bytes      → life_bytes
  rand-bytes      → rand_bytes
  rekey-packets   → rekey_packets
  life-packets    → life_packets
  rand-packets    → rand_packets
  pool address    → addrs
  boolean True    → yes, False → no
"""


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _bool(val):
    """Convert XCESP boolean string to swanctl yes/no."""
    if isinstance(val, str):
        return "yes" if val.lower() in ("true", "yes", "1") else "no"
    return "yes" if val else "no"


def _any(val):
    """Translate '*' wildcard to swanctl '%any'."""
    if not val or val == "*":
        return "%any"
    return val


def _proposals_list(node):
    """Return comma-joined algorithm strings from a proposals/esp-proposals/ah-proposals node."""
    if not node:
        return ""
    algos = [a["instance_name"] for a in (node.get("children") or {}).get("algorithm", [])]
    return ",".join(algos)


def _ts_list(node):
    """Return comma-joined traffic selector strings from a local-ts/remote-ts node."""
    if not node:
        return ""
    matches = [m["instance_name"] for m in (node.get("children") or {}).get("match", [])]
    return ",".join(matches)


# ---------------------------------------------------------------------------
# Connection rendering
# ---------------------------------------------------------------------------

# Simple attr → swanctl-key mappings for connection-level params
_CONN_ATTR_MAP = [
    ("version",           "version"),
    ("local-address",     None),       # handled specially (_any)
    ("remote-address",    None),       # handled specially (_any)
    ("local-port",        "local_port"),
    ("remote-port",       "remote_port"),
    ("virtual-address",   "vips"),
    ("pools",             "pools"),
    ("dscp",              "dscp"),
    ("dpd-delay",         "dpd_delay"),
    ("dpd-timeout",       "dpd_timeout"),
    ("keying-tries",      "keying_tries"),
    ("reauth-time",       "reauth_time"),
    ("rekey-time",        "rekey_time"),
    ("over-time",         "over_time"),
    ("rand-time",         "rand_time"),
    ("ocsp",              "ocsp"),
    ("fragmentation",     "fragmentation"),
    ("childless",         "childless"),
    ("send-cert",         "send_cert"),
    ("unique",            "unique"),
]

_CONN_BOOL_MAP = [
    ("aggressive",        "aggressive"),
    ("encapsulation",     "encap"),
    ("mobike",            "mobike"),
    ("send-cert-request", "send_certreq"),
]


def _render_connection(conn):
    name = conn["instance_name"]
    a    = conn.get("attrs", {})
    ch   = conn.get("children") or {}
    lines = []
    lines.append(f"  {name} {{")

    # Simple string/integer attrs
    for xcesp_key, swan_key in _CONN_ATTR_MAP:
        val = a.get(xcesp_key, "")
        if not val:
            continue
        if xcesp_key == "local-address":
            lines.append(f"    local_addrs = {_any(val)}")
        elif xcesp_key == "remote-address":
            lines.append(f"    remote_addrs = {_any(val)}")
        else:
            lines.append(f"    {swan_key} = {val}")

    # Boolean attrs
    for xcesp_key, swan_key in _CONN_BOOL_MAP:
        val = a.get(xcesp_key, "")
        if val != "":
            lines.append(f"    {swan_key} = {_bool(val)}")

    # IKE proposals
    props = ch.get("proposals", [])
    if props:
        algo_str = _proposals_list(props[0])
        if algo_str:
            lines.append(f"    proposals = {algo_str}")

    # local-<N> auth rounds
    for loc in ch.get("local", []):
        lines += _render_auth_round("local", loc)

    # remote-<N> auth rounds
    for rem in ch.get("remote", []):
        lines += _render_auth_round("remote", rem)

    # children { ... }
    child_list = ch.get("children", [])
    if child_list:
        lines.append("    children {")
        for child in child_list:
            lines += _render_child(child)
        lines.append("    }")

    lines.append("  }")
    return lines


# Auth round (local/remote)
_LOCAL_ATTR_MAP = [
    ("auth",      "auth"),
    ("id",        None),       # handled specially (_any)
    ("eap-id",    "eap_id"),
    ("aaa-id",    "aaa_id"),
    ("xauth-id",  "xauth_id"),
]

_REMOTE_EXTRA_MAP = [
    ("ca-id",       "ca_id"),
    ("groups",      "groups"),
    ("cert-policy", "cert_policy"),
    ("revocation",  "revocation"),
]


def _render_auth_round(kind, node):
    """kind is 'local' or 'remote', node['instance_name'] is the round integer."""
    round_id = node["instance_name"]
    a = node.get("attrs", {})
    lines = []
    lines.append(f"    {kind}-{round_id} {{")

    for xcesp_key, swan_key in _LOCAL_ATTR_MAP:
        val = a.get(xcesp_key, "")
        if not val:
            continue
        if xcesp_key == "id":
            lines.append(f"      id = {_any(val)}")
        else:
            lines.append(f"      {swan_key} = {val}")

    if kind == "remote":
        for xcesp_key, swan_key in _REMOTE_EXTRA_MAP:
            val = a.get(xcesp_key, "")
            if val:
                lines.append(f"      {swan_key} = {val}")

    lines.append("    }")
    return lines


# CHILD_SA
_CHILD_ATTR_MAP = [
    ("rekey-time",      "rekey_time"),
    ("life-time",       "life_time"),
    ("rand-time",       "rand_time"),
    ("rekey-bytes",     "rekey_bytes"),
    ("life-bytes",      "life_bytes"),
    ("rand-bytes",      "rand_bytes"),
    ("rekey-packets",   "rekey_packets"),
    ("life-packets",    "life_packets"),
    ("rand-packets",    "rand_packets"),
    ("inactivity",      "inactivity"),
    ("replay-window",   "replay_window"),
    ("mode",            "mode"),
    ("dpd-action",      "dpd_action"),
    ("close-action",    "close_action"),
    ("per-cpu-sas",     "per_cpu_sas"),
    ("hw-offload",      "hw_offload"),
    ("copy-dscp",       "copy_dscp"),
]

_CHILD_BOOL_MAP = [
    ("policies",         "policies"),
    ("policies-fwd-out", "policies_fwd_out"),
    ("ipcomp",           "ipcomp"),
    ("copy-df",          "copy_df"),
    ("copy-ecn",         "copy_ecn"),
    ("icmp-error",       "icmp"),
]


def _render_child(node):
    name = node["instance_name"]
    a    = node.get("attrs", {})
    ch   = node.get("children") or {}
    lines = []
    lines.append(f"      {name} {{")

    # ESP proposals
    esp = ch.get("esp-proposals", [])
    if esp:
        s = _proposals_list(esp[0])
        if s:
            lines.append(f"        esp_proposals = {s}")

    # AH proposals
    ah = ch.get("ah-proposals", [])
    if ah:
        s = _proposals_list(ah[0])
        if s:
            lines.append(f"        ah_proposals = {s}")

    # Traffic selectors
    lts = ch.get("local-ts", [])
    if lts:
        s = _ts_list(lts[0])
        if s:
            lines.append(f"        local_ts = {s}")

    rts = ch.get("remote-ts", [])
    if rts:
        s = _ts_list(rts[0])
        if s:
            lines.append(f"        remote_ts = {s}")

    # Simple attrs
    for xcesp_key, swan_key in _CHILD_ATTR_MAP:
        val = a.get(xcesp_key, "")
        if not val:
            continue
        lines.append(f"        {swan_key} = {val}")

    # start-action: trapstart → trap|start
    sa = a.get("start-action", "")
    if sa:
        swan_sa = "trap|start" if sa == "trapstart" else sa
        lines.append(f"        start_action = {swan_sa}")

    # Boolean flags
    for xcesp_key, swan_key in _CHILD_BOOL_MAP:
        val = a.get(xcesp_key, "")
        if val != "":
            lines.append(f"        {swan_key} = {_bool(val)}")

    lines.append("      }")
    return lines


# ---------------------------------------------------------------------------
# Secret rendering
# ---------------------------------------------------------------------------

def _render_secret(secret):
    name   = secret["instance_name"]
    a      = secret.get("attrs", {})
    ch     = secret.get("children") or {}
    stype  = a.get("type", "ike")
    lines  = []
    lines.append(f"  {stype}-{name} {{")

    sec = a.get("secret", "")
    if sec:
        lines.append(f"    secret = {sec}")

    for id_node in ch.get("id", []):
        id_label = id_node["instance_name"]
        match    = (id_node.get("attrs") or {}).get("match", "")
        if not match:
            continue
        # Special case: wildcard id — emit "id = %any"
        if id_label == "*" or match == "*":
            lines.append("    id = %any")
        else:
            lines.append(f"    id-{id_label} = {_any(match)}")

    lines.append("  }")
    return lines


# ---------------------------------------------------------------------------
# Pool rendering
# ---------------------------------------------------------------------------

def _render_pool(pool):
    name = pool["instance_name"]
    a    = pool.get("attrs", {})
    addr = a.get("address", "")
    lines = [f"  {name} {{"]
    if addr:
        lines.append(f"    addrs = {addr}")
    lines.append("  }")
    return lines


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def run(data):
    """
    Called by xcespmap for the 'ipsec' child node of 'router'.
    data["parent"]["instance_name"] is the router (namespace) name.
    Emits SWAN_LINE_* keys into the existing object.swan-<ns> section.
    """
    attrs    = data.get("attrs") or {}
    children = data.get("children") or {}

    # Derive namespace from parent (router) node
    parent = data.get("parent") or {}
    ns     = parent.get("instance_name", "default")

    # Build swanctl.conf lines
    lines = []

    # --- connections { ... } ---
    connections = children.get("connection", [])
    if connections:
        lines.append("connections {")
        for conn in connections:
            lines += _render_connection(conn)
        lines.append("}")

    # --- secrets { ... } ---
    secrets = children.get("secret", [])
    if secrets:
        lines.append("secrets {")
        for sec in secrets:
            lines += _render_secret(sec)
        lines.append("}")

    # --- pools { ... } ---
    pools = children.get("pool", [])
    if pools:
        lines.append("pools {")
        for pool in pools:
            lines += _render_pool(pool)
        lines.append("}")

    # Pack as indexed INI keys into the existing RtrStrongswan section
    obj_attrs = {
        "SWAN_LINE_COUNT": str(len(lines)),
    }
    for i, line in enumerate(lines):
        obj_attrs[f"SWAN_LINE_{i}"] = line

    return [
        {
            "section": f"object.swan-{ns}",
            "attrs":   obj_attrs,
        }
    ]
