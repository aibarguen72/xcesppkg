#!/usr/bin/env python3
"""
config-to-objects/vlan.py — XCESP-ON-RTR  [RETIRED]

This rule is no longer invoked.  The 'vlan' node type was previously a
direct child of 'vrf'.  It has been migrated to a sub-block of 'interface'
(type=vlan).  VLAN handling is now done in interface.py.

The file is kept to avoid confusion if someone runs old configs.
"""

NEEDS_FULL_CONFIG = True


def run(data):
    # vlan is no longer a top-level vrf child — this rule should not be called.
    return []
