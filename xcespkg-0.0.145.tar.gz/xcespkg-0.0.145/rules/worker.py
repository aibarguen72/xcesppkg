#!/usr/bin/env python3
# worker.py — persistent rule dispatcher for xcespmap
#
# Reads newline-delimited JSON requests from stdin:
#   {"script": "<path>.py", "data": <dict>}
# Writes one JSON result line to stdout per request.
#
# Rule scripts must export:  def run(data: dict) -> list

import sys
import json
import importlib.util

cache = {}

for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    try:
        req = json.loads(line)
        path = req["script"]
        if path not in cache:
            spec = importlib.util.spec_from_file_location("rule", path)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            cache[path] = mod
        result = cache[path].run(req["data"])
        print(json.dumps(result), flush=True)
    except BaseException:
        print("[]", flush=True)
