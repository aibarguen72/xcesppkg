#!/usr/bin/env python3
"""
status-to-global/vrf.py — XCESP-ON-RTR
Maps RtrVrf, RtrBgp, RtrOspf, RtrOspf6, RtrRip, and RtrRipng object status
to global path/value pairs.

RtrVrf: node_path is the VRF path; emit node_path/oper-status directly.

RtrBgp/RtrOspf/RtrOspf6/RtrRip/RtrRipng: emitted by the vrf config-to-objects
  rule so node_path is the parent VRF path.  The proc/instance is stored as
  the "proc" field in the status JSON; the path is:
    {node_path}/ospf/{proc}/oper-status    (OSPFv2)
    {node_path}/ospf6/{proc}/oper-status   (OSPFv3)
    {node_path}/rip/{proc}/oper-status     (RIPv2)
    {node_path}/ripng/{proc}/oper-status   (RIPng)
"""


def run(data):
    result = []
    for obj in data.get("objects", []):
        obj_type = obj.get("type", "")
        path = (obj.get("node_path")
                or f"{obj.get('node_type','vrf')}/{obj.get('node_instance','?')}")

        if obj_type == "RtrVrf":
            result.append({"path": f"{path}/oper-status",
                            "value": obj.get("oper_status", "LLD")})

        elif obj_type == "RtrBgp":
            bgp_node = obj.get("bgp_node", "bgp")
            bgp_name = obj.get("bgp_name", "")
            if bgp_name:
                result.append({"path": f"{path}/{bgp_node}/{bgp_name}/oper-status",
                                "value": obj.get("oper_status", "LLD")})

        elif obj_type == "RtrOspf":
            proc = obj.get("proc", "1")
            result.append({"path": f"{path}/ospf/{proc}/oper-status",
                            "value": obj.get("oper_status", "LLD")})

        elif obj_type == "RtrOspf6":
            proc = obj.get("proc", "1")
            result.append({"path": f"{path}/ospf6/{proc}/oper-status",
                            "value": obj.get("oper_status", "LLD")})

        elif obj_type == "RtrRip":
            proc = obj.get("proc", "1")
            result.append({"path": f"{path}/rip/{proc}/oper-status",
                            "value": obj.get("oper_status", "LLD")})

        elif obj_type == "RtrRipng":
            proc = obj.get("proc", "1")
            result.append({"path": f"{path}/ripng/{proc}/oper-status",
                            "value": obj.get("oper_status", "LLD")})

    return result
