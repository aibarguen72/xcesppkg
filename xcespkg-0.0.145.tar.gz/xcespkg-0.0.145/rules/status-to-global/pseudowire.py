"""
status-to-global/pseudowire.py — XCESP-ON-PW
Maps xcespproc object status back to global path/value pairs.

TODO: implement when CesoPsnPObj / SaTopPObj are ready.
      Return a list of {"path": "...", "value": "..."} dicts.
"""


def run(data):
    """
    data: dict with key "objects" containing a list of per-object status dicts,
          each with at minimum "node_path", "node_instance", and "status" keys.

    Return a list of path/value pairs, e.g.:
        [{"path": "domain/main/pseudowire/pw-a/status", "value": "ACTIVE"}]
    """
    return []
