#!/usr/bin/env python3
"""
status-to-global/nat-dnat.py — XCESP-ON-RTR
Maps RtrNatDnat object status to global path/value pairs.
"""


def run(data):
    result = []
    for obj in data.get("objects", []):
        path = (obj.get("node_path")
                or f"{obj.get('node_type','nat-dnat')}/{obj.get('node_instance','?')}")
        result.append({"path": f"{path}/oper-status",
                        "value": obj.get("oper_status", "LLD")})
    return result
