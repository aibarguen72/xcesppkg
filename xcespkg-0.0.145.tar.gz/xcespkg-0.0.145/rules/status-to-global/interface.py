#!/usr/bin/env python3
"""
status-to-global/interface.py — XCESP-ON-RTR
Maps RtrInterface object status to global path/value pairs.
Emits oper-status and link-state.
"""


def run(data):
    result = []
    for obj in data.get("objects", []):
        path = (obj.get("node_path")
                or f"{obj.get('node_type','interface')}/{obj.get('node_instance','?')}")
        result.append({"path": f"{path}/oper-status",
                        "value": obj.get("oper_status", "LLD")})
        result.append({"path": f"{path}/link-state",
                        "value": obj.get("link_state", "DOWN")})
        nhrp_state = obj.get("nhrp_state")
        if nhrp_state is not None:
            result.append({"path": f"{path}/nhrp-state", "value": nhrp_state})
    return result
