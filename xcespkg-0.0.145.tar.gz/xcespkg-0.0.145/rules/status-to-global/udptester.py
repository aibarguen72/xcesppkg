#!/usr/bin/env python3
# status-to-global/udptester.py
# Maps udptester STATUS_REPORT objects to global path/value pairs.
#
# Uses node_path (injected at deploy time) for full hierarchical paths.
# Falls back to flat udptester/<instance> if node_path is absent.

def run(data):
    result = []
    for obj in data.get('objects', []):
        instance  = obj.get('node_instance') or obj.get('name', 'unknown')
        node_path = obj.get('node_path') or f"udptester/{instance}"
        name      = obj.get('name', instance)
        stats     = obj.get('stats', {})

        # Node-level mapped attrs (schema-defined, kebab-case)
        result.append({"path": f"{node_path}/status",
                        "value": obj.get('status', 'unknown')})
        result.append({"path": f"{node_path}/packets-sent",
                        "value": str(stats.get('packetsSent', 0))})
        result.append({"path": f"{node_path}/packets-received",
                        "value": str(stats.get('packetsReceived', 0))})

        # Raw object attrs (for detail view, original camelCase names)
        result.append({"path": f"{node_path}/objects/{name}/status",
                        "value": obj.get('status', 'unknown')})
        result.append({"path": f"{node_path}/objects/{name}/packetsSent",
                        "value": str(stats.get('packetsSent', 0))})
        result.append({"path": f"{node_path}/objects/{name}/packetsReceived",
                        "value": str(stats.get('packetsReceived', 0))})

    return result
