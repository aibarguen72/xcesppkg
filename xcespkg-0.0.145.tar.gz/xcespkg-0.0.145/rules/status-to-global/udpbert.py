#!/usr/bin/env python3
# status-to-global/udpbert.py
# Maps udpbert STATUS_REPORT objects to global path/value pairs.
#
# Each udpbert instance has two C++ objects (UdpTester + PktBert).
# Uses node_path (injected at deploy time) for full hierarchical paths.
# Falls back to flat udpbert/<instance> if node_path is absent.

def run(data):
    result = []

    # Group objects by node_path (or fall back to type/instance)
    by_path = {}
    for obj in data.get('objects', []):
        instance  = obj.get('node_instance') or obj.get('name', 'unknown')
        node_path = obj.get('node_path') or f"udpbert/{instance}"
        by_path.setdefault(node_path, []).append(obj)

    for node_path, objs in by_path.items():
        node = {}  # merged node-level attrs

        for obj in objs:
            name     = obj.get('name', node_path.split('/')[-1])
            obj_type = obj.get('type', '')
            stats    = obj.get('stats', {})

            # Accumulate node-level attrs from each object
            if obj_type == 'UdpTester':
                node['status']           = obj.get('status', 'unknown')
                node['packets-sent']     = str(stats.get('packetsSent', 0))
                node['packets-received'] = str(stats.get('packetsReceived', 0))
            elif obj_type == 'PktBert':
                node['good-packets'] = str(stats.get('goodPackets', 0))
                node['bad-packets']  = str(stats.get('badPackets', 0))
                node['sync-ok']      = str(stats.get('syncOk', False)).lower()

            # Raw object attrs (for detail view)
            result.append({"path": f"{node_path}/objects/{name}/type",
                            "value": obj_type})
            result.append({"path": f"{node_path}/objects/{name}/status",
                            "value": obj.get('status', 'unknown')})
            for k, v in stats.items():
                result.append({"path": f"{node_path}/objects/{name}/{k}",
                                "value": str(v)})

        # Node-level attrs in schema-defined order
        for attr in ('status', 'packets-sent', 'packets-received',
                     'good-packets', 'bad-packets', 'sync-ok'):
            if attr in node:
                result.append({"path": f"{node_path}/{attr}",
                                "value": node[attr]})

    return result
