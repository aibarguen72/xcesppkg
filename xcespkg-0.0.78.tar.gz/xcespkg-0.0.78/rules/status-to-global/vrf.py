#!/usr/bin/env python3
"""
status-to-global/vrf.py — XCESP-ON-RTR
Maps RtrVrf and RtrBgp object status to global path/value pairs.

RtrVrf: node_path is the VRF path (e.g. router/RA/vrf/default); emit
  node_path/oper-status directly.

RtrBgp: xcespmap injects the parent VRF's node_path into all objects emitted
  by the vrf config-to-objects rule (e.g. router/RA/vrf/default), not the
  bgp instance's own path.  RtrBgpPObj therefore emits two extra fields in
  its status JSON — bgp_node (bgp/bgp-vrf/bgp-view) and bgp_name (ASN or
  instance name) — so we can construct the correct path here:
    {node_path}/{bgp_node}/{bgp_name}/oper-status
"""


def run(data):
    result = []
    for obj in data.get("objects", []):
        obj_type = obj.get("type", "")
        path = (obj.get("node_path")
                or f"{obj.get('node_type','vrf')}/{obj.get('node_instance','?')}")

        if obj_type == "RtrVrf":
            result.append({"path": f"{path}/oper-status",
                            "value": obj.get("oper_status", "LLD")})

        elif obj_type == "RtrBgp":
            bgp_node = obj.get("bgp_node", "bgp")
            bgp_name = obj.get("bgp_name", "")
            if bgp_name:
                result.append({"path": f"{path}/{bgp_node}/{bgp_name}/oper-status",
                                "value": obj.get("oper_status", "LLD")})

    return result
