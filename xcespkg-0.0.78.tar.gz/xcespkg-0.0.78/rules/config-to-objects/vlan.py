#!/usr/bin/env python3
"""
config-to-objects/vlan.py — XCESP-ON-RTR
Maps a 'vlan' config node to one RtrVlan xcespproc object.

Same-namespace mode (no parent-router attr):
  The parent device name is looked up from the parent vrf node's interface
  children, matching by the 'interface' attr value (instance name).

Cross-namespace mode (parent-router attr present):
  The 'interface' attr is the XCESP instance name of an interface in the
  parent router's namespace.  The Linux device name is resolved from the
  full config via data["config"] (injected by xcespmap when this file
  declares NEEDS_FULL_CONFIG = True).  A macvlan is created over the VLAN
  subinterface in the parent NS and moved to this VLAN's router namespace.

Multiple IP addresses are collected from child 'address' nodes.
"""

NEEDS_FULL_CONFIG = True


def run(data):
    attrs = data["attrs"]

    parent_router = attrs.get("parent-router", "")
    if parent_router:
        # Cross-namespace: resolve interface instance name → Linux device name
        # by traversing the full config tree supplied in data["config"].
        parent_if_name = attrs.get("interface", "")
        parent_device  = ""
        parent_ns      = parent_router
        for rtr in data.get("config", {}).get("router", []):
            if rtr["instance_name"] != parent_router:
                continue
            for vrf_node in rtr.get("children", {}).get("vrf", []):
                for iface in vrf_node.get("children", {}).get("interface", []):
                    if iface["instance_name"] == parent_if_name:
                        parent_device = iface["attrs"].get("device", parent_if_name)
                        break
    else:
        # Same-namespace: look up interface instance in sibling vrf interfaces
        parent_if_name = attrs.get("interface", "")
        parent_device  = ""
        for iface in data.get("parent", {}).get("children", {}).get("interface", []):
            if iface["instance_name"] == parent_if_name:
                parent_device = iface["attrs"].get("device", iface["instance_name"])
                break
        parent_ns = ""

    addresses = ",".join(
        a["instance_name"]
        for a in data.get("children", {}).get("address", [])
    )
    return [
        {
            "section": f"object.vlan-{data['instance_name']}",
            "attrs": {
                "TYPE":          "RtrVlan",
                "NAME":          "vlan_" + data["instance_name"],
                "PARENT_DEVICE": parent_device,
                "PARENT_NS":     parent_ns,
                "VLAN_ID":       attrs.get("vlanid", "0"),
                "ADDRESSES":     addresses,
                "SHUTDOWN":      attrs.get("shutdown", "true"),
            },
        }
    ]
