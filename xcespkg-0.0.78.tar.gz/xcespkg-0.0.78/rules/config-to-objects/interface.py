#!/usr/bin/env python3
"""
config-to-objects/interface.py — XCESP-ON-RTR
Maps an 'interface' config node to one RtrInterface xcespproc object.

Multiple IP addresses are collected from child 'address' nodes whose
instance names carry the IP/prefix (e.g. "10.10.10.10/24").
Namespace and VRF are derived from NODE_PATH injected by xcespmap.

IFACE_TYPE values:
  device   (default) — existing Linux device; check existence, sync IPs
  loopback           — dummy interface (or standard 'lo'); create if needed
  rlink              — veth pair endpoint; LINK carries the shared link name
  gre                — GRE tunnel; GRE_* attrs carry tunnel parameters
"""


def run(data):
    attrs  = data["attrs"]
    # For rlink/gre, 'device' is optional and defaults to the interface instance name
    device = attrs.get("device", data["instance_name"])
    addresses = ",".join(
        a["instance_name"]
        for a in data.get("children", {}).get("address", [])
    )
    obj = {
        "section": f"object.iface-{data['instance_name']}",
        "attrs": {
            "TYPE":       "RtrInterface",
            "NAME":       "interface_" + data["instance_name"],
            "DEVICE":     device,
            "IFACE_TYPE": attrs.get("type", "device"),
            "LINK":       attrs.get("link", ""),
            "ADDRESSES":  addresses,
            "SHUTDOWN":   attrs.get("shutdown", "true"),
            "MPLS":       attrs.get("mpls",     "false"),
        },
    }

    gre_block = data.get("children", {}).get("gre", [])
    if gre_block:
        g = gre_block[0].get("attrs", {})
        obj["attrs"]["GRE_SOURCE"]      = g.get("source",      "")
        obj["attrs"]["GRE_DESTINATION"] = g.get("destination", "")
        obj["attrs"]["GRE_INTERFACE"]   = g.get("interface",   "")
        obj["attrs"]["GRE_KEY"]         = str(g.get("key", ""))
        obj["attrs"]["GRE_TTL"]         = str(g.get("ttl", ""))

        nhrp_nodes = gre_block[0].get("children", {}).get("nhrp", [])
        if nhrp_nodes:
            n  = nhrp_nodes[0]
            na = n.get("attrs", {})
            obj["attrs"]["NHRP_ENABLED"]               = "true"
            obj["attrs"]["NHRP_AUTH"]                  = na.get("authentication", "")
            obj["attrs"]["NHRP_HOLDTIME"]              = str(na.get("holdtime", ""))
            obj["attrs"]["NHRP_NETWORK_ID"]            = str(na.get("network-id", ""))
            obj["attrs"]["NHRP_MTU"]                   = str(na.get("mtu", ""))
            obj["attrs"]["NHRP_REGISTRATION_NO_UNIQUE"] = str(na.get("registration-no-unique", "false"))
            obj["attrs"]["NHRP_SHORTCUT"]              = str(na.get("shortcut", "false"))
            maps = n.get("children", {}).get("nhrp-map", [])
            obj["attrs"]["NHRP_MAPS"] = ",".join(
                f"{m['instance_name']}:{m['attrs']['nbma']}" for m in maps)
            nhs_list = n.get("children", {}).get("nhrp-nhs", [])
            obj["attrs"]["NHRP_NHS"] = ",".join(
                f"{s['instance_name']}:{s['attrs']['nbma']}" for s in nhs_list)

    return [obj]
