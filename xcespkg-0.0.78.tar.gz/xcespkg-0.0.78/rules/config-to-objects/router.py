#!/usr/bin/env python3
"""
config-to-objects/router.py — XCESP-ON-RTR
Maps a 'router' config node to one RtrRouter xcespproc object, and optionally
to one RtrFrr object when a 'dynamic-routing' child block is present.

Also emits RtrAcl objects for each bgp-as-path-acl, bgp-community-list-standard,
bgp-community-list-expanded, and prefix-list child block.

The router instance name becomes the Linux network namespace name.
"default" is the host namespace (no namespace is created/managed).
"""

# Map of (schema child type → ACL_TYPE INI value)
_LIST_TYPES = {
    "bgp-as-path-acl":              "as-path-acl",
    "bgp-community-list-standard":  "community-list-standard",
    "bgp-community-list-expanded":  "community-list-expanded",
    "prefix-list":                  "prefix-list",
    "access-list":                  "access-list",
    "access-list-extended":         "access-list-extended",
}


def _extract_rules(list_node):
    """Extract ordered permit/deny rules from a list node.

    Returns list of dicts with action, value, seq, ge, le.
    Permits are emitted first (in document order), then denys.
    Use seq attribute to control explicit FRR ordering.
    """
    rules = []
    children = list_node.get("children") or {}
    for action_type in ("acl-permit", "acl-deny"):
        frr_action = action_type.replace("acl-", "")  # "permit" or "deny"
        for rule in children.get(action_type, []):
            a = rule.get("attrs", {})
            rules.append({
                "action": frr_action,
                "value":  rule["instance_name"],
                "seq":    a.get("seq", ""),
                "ge":     a.get("ge", ""),
                "le":     a.get("le", ""),
            })
    return rules


def run(data):
    ns = data["instance_name"]

    objects = [
        {
            "section": f"object.router-{ns}",
            "attrs": {
                "TYPE":           "RtrRouter",
                "NAME":           "router_" + ns,
                "NAMESPACE":       ns,
                "SHUTDOWN":        data["attrs"].get("shutdown",   "false"),
                "FORWARDING":      data["attrs"].get("forwarding", "true"),
                "ROUTER_ID":       data["attrs"].get("router-id",  "0.0.0.0"),
                "MPLS":            "false",
                "MPLS_MAX_LABELS": "1000",
            },
        }
    ]

    # Emit RtrFrr object when dynamic-routing child is present
    dr = (data.get("children") or {}).get("dynamic-routing", [])
    if dr:
        d = dr[0]   # at most one dynamic-routing child per router
        a = d.get("attrs", {})
        objects[0]["attrs"]["MPLS"]            = a.get("mpls",            "false")
        objects[0]["attrs"]["MPLS_MAX_LABELS"] = str(a.get("mpls-max-labels", "1000"))
        objects.append({
            "section": f"object.frr-{ns}",
            "attrs": {
                "TYPE":      "RtrFrr",
                "NAME":      "frr_" + ns,
                "NAMESPACE": ns,
                "SHUTDOWN":  a.get("shutdown", "false"),
                "ROUTER_ID": data["attrs"].get("router-id", "0.0.0.0"),
                "BGP":       a.get("bgp",    "false"),
                "NHRP":      a.get("nhrp",   "false"),
                "OSPF":      a.get("ospf",   "false"),
                "OSPF6":     a.get("ospf6",  "false"),
                "RIP":       a.get("rip",    "false"),
                "RIPNG":     a.get("ripng",  "false"),
                "LDP":       a.get("ldp",    "false"),
                "BABEL":     a.get("babel",  "false"),
                "PIM":       a.get("pim",    "false"),
            },
        })

    # Emit RtrAcl objects for ACL / community-list / prefix-list children
    for schema_type, acl_type in _LIST_TYPES.items():
        for lst in (data.get("children") or {}).get(schema_type, []):
            name  = lst["instance_name"]
            rules = _extract_rules(lst)
            obj_a = {
                "TYPE":       "RtrAcl",
                "NAME":       f"acl_{acl_type}_{ns}_{name}",
                "ACL_TYPE":   acl_type,
                "ACL_NAME":   name,
                "RULE_COUNT": str(len(rules)),
            }
            for i, r in enumerate(rules):
                obj_a[f"RULE_{i}_ACTION"] = r["action"]
                obj_a[f"RULE_{i}_VALUE"]  = r["value"]
                obj_a[f"RULE_{i}_SEQ"]    = r["seq"]
                obj_a[f"RULE_{i}_GE"]     = r["ge"]
                obj_a[f"RULE_{i}_LE"]     = r["le"]
            objects.append({
                "section": f"object.acl-{acl_type}-{ns}-{name}",
                "attrs": obj_a,
            })

    # Emit RtrRouteMap objects for route-map children
    for rmap in (data.get("children") or {}).get("route-map", []):
        rmap_name = rmap["instance_name"]
        rmap_lines = _build_rmap_lines(rmap_name, rmap)
        obj_a = {
            "TYPE":       "RtrRouteMap",
            "NAME":       f"rmap_{ns}_{rmap_name}",
            "RMAP_NAME":  rmap_name,
            "RULE_COUNT": str(len(rmap_lines)),
        }
        for i, line in enumerate(rmap_lines):
            obj_a[f"RULE_{i}"] = line
        objects.append({
            "section": f"object.rmap-{ns}-{rmap_name}",
            "attrs": obj_a,
        })

    return objects


# ---------------------------------------------------------------------------
# Route-map helpers
# ---------------------------------------------------------------------------

# Match attrs: (XCESPCLI attr name, FRR command suffix)
_MATCH_MAP = [
    ("match-ip-address",               "match ip address"),
    ("match-ipv6-address",             "match ipv6 address"),
    ("match-ip-address-prefix-list",   "match ip address prefix-list"),
    ("match-ipv6-address-prefix-list", "match ipv6 address prefix-list"),
    ("match-ip-next-hop-address",      "match ip next-hop address"),
    ("match-ipv6-next-hop-address",    "match ipv6 next-hop address"),
    ("match-ip-next-hop",              "match ip next-hop"),
    ("match-ipv6-next-hop",            "match ipv6 next-hop"),
    ("match-ip-next-hop-prefix-list",  "match ip next-hop prefix-list"),
    ("match-ipv6-next-hop-prefix-list","match ipv6 next-hop prefix-list"),
    ("match-as-path",                  "match as-path"),
    ("match-metric",                   "match metric"),
    ("match-vpn-dataplane",            "match vpn dataplane"),
    ("match-local-preference",         "match local-preference"),
    ("match-source-protocol",          "match source-protocol"),
    ("match-evpn-route-type",          "match evpn route-type"),
    ("match-evpn-vni",                 "match evpn vni"),
    ("match-src-peer-address-ip",      "match src-peer"),
    ("match-src-peer-address-ipv6",    "match src-peer"),
    ("match-src-peer-interface",       "match src-peer"),
    ("match-src-peer-group",           "match src-peer"),
    ("match-peer-address-ip",          "match peer"),
    ("match-peer-address-ipv6",        "match peer"),
    ("match-peer-interface",           "match peer"),
    ("match-peer-group",               "match peer"),
]


def _build_rmap_lines(rmap_name, rmap_node):
    """Build FRR lines for all rules in a route-map. Returns list of strings."""
    lines = []
    children = rmap_node.get("children") or {}
    for action_type in ("rmap-permit", "rmap-deny"):
        frr_action = action_type.replace("rmap-", "")
        for rule in children.get(action_type, []):
            order = rule["instance_name"]
            a = rule.get("attrs", {})
            # Header
            lines.append(f"route-map {rmap_name} {frr_action} {order}")
            # Match
            _emit_rmap_match(lines, a)
            # Set
            _emit_rmap_set(lines, a)
            # Call
            if a.get("call"):
                lines.append(f" call {a['call']}")
            # Exit
            if a.get("on-match-next") in ("true", "True", True):
                lines.append(" on-match next")
            if a.get("on-match-goto"):
                lines.append(f" on-match goto {a['on-match-goto']}")
            if a.get("continue"):
                lines.append(f" continue {a['continue']}")
            # Close stanza
            lines.append("!")
    return lines


def _emit_rmap_match(lines, a):
    """Emit the match line for a route-map rule."""
    # tag special case: 0 = untagged
    tag = a.get("match-tag", "")
    if tag:
        lines.append(f" match tag {'untagged' if tag == '0' else tag}")
        return
    # community special cases
    if a.get("match-community-exact"):
        lines.append(f" match community {a['match-community-exact']} exact-match")
        return
    if a.get("match-community-any"):
        lines.append(f" match community {a['match-community-any']} any")
        return
    # Generic match attrs
    for xcli, frr in _MATCH_MAP:
        val = a.get(xcli, "")
        if val:
            lines.append(f" {frr} {val}")
            return


def _emit_rmap_set(lines, a):
    """Emit set lines for a route-map rule. Multiple set lines can coexist."""
    # tag
    tag = a.get("set-tag", "")
    if tag:
        lines.append(f" set tag {'untagged' if tag == '0' else tag}")
    # ip next-hop (mutually exclusive options)
    if a.get("set-ip-next-hop"):
        lines.append(f" set ip next-hop {a['set-ip-next-hop']}")
    elif a.get("set-ip-next-hop-peer-address") in ("true", "True", True):
        lines.append(" set ip next-hop peer-address")
    elif a.get("set-ip-next-hop-unchanged") in ("true", "True", True):
        lines.append(" set ip next-hop unchanged")
    # ipv6 next-hop
    if a.get("set-ipv6-next-hop-global"):
        lines.append(f" set ipv6 next-hop global {a['set-ipv6-next-hop-global']}")
    if a.get("set-ipv6-next-hop-local"):
        lines.append(f" set ipv6 next-hop local {a['set-ipv6-next-hop-local']}")
    if a.get("set-ipv6-next-hop-peer-address") in ("true", "True", True):
        lines.append(" set ipv6 next-hop peer-address")
    if a.get("set-ipv6-next-hop-prefer-global") in ("true", "True", True):
        lines.append(" set ipv6 next-hop prefer-global")
    # local-preference (mutually exclusive)
    if a.get("set-local-preference"):
        lines.append(f" set local-preference {a['set-local-preference']}")
    elif a.get("set-local-preference-add"):
        lines.append(f" set local-preference +{a['set-local-preference-add']}")
    elif a.get("set-local-preference-sub"):
        lines.append(f" set local-preference -{a['set-local-preference-sub']}")
    # distance, weight
    if a.get("set-distance"):
        lines.append(f" set distance {a['set-distance']}")
    if a.get("set-weight"):
        lines.append(f" set weight {a['set-weight']}")
    # metric (mutually exclusive)
    if a.get("set-metric"):
        lines.append(f" set metric {a['set-metric']}")
    elif a.get("set-metric-add"):
        lines.append(f" set metric +{a['set-metric-add']}")
    elif a.get("set-metric-sub"):
        lines.append(f" set metric -{a['set-metric-sub']}")
    elif a.get("set-metric-value"):
        lines.append(f" set metric {a['set-metric-value']}")
    # min/max metric
    if a.get("set-min-metric"):
        lines.append(f" set min-metric {a['set-min-metric']}")
    if a.get("set-max-metric"):
        lines.append(f" set max-metric {a['set-max-metric']}")
    # aigp-metric
    if a.get("set-aigp-metric"):
        lines.append(f" set aigp-metric {a['set-aigp-metric']}")
    elif a.get("set-aigp-metric-igp") in ("true", "True", True):
        lines.append(" set aigp-metric igp")
    # as-path
    if a.get("set-as-path-prepend"):
        lines.append(f" set as-path prepend {a['set-as-path-prepend']}")
    if a.get("set-as-path-exclude"):
        lines.append(f" set as-path exclude {a['set-as-path-exclude']}")
    # community, origin, table
    if a.get("set-community"):
        lines.append(f" set community {a['set-community']}")
    if a.get("set-origin"):
        lines.append(f" set origin {a['set-origin']}")
    if a.get("set-table"):
        lines.append(f" set table {a['set-table']}")
    if a.get("set-sr-te-color"):
        lines.append(f" set sr-te color {a['set-sr-te-color']}")
    if a.get("set-l3vpn-next-hop-encapsulation-gre") in ("true", "True", True):
        lines.append(" set l3vpn next-hop encapsulation gre")
