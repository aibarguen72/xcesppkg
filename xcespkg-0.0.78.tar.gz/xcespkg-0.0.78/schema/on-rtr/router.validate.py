#!/usr/bin/env python3
# router.validate.py — affinity conflict check + address/route instance validation
#
# Invoked by validateHooks() as:
#   python3 router.validate.py router <instancename>
# Full config text is provided on stdin.
# Any line printed to stdout is treated as a validation error.

import sys
import re
import ipaddress

node_type = sys.argv[1]   # "router"
instance  = sys.argv[2]   # e.g. "default"
config    = sys.stdin.read()

# --------------------------------------------------------------------------
# Parse all top-level router blocks
# --------------------------------------------------------------------------
routers = {}   # name -> {"affinity": int|None, "block": [lines...]}
lines   = config.splitlines()
i = 0

while i < len(lines):
    m = re.match(r'^router\s+(\S+)', lines[i])
    if m:
        name     = m.group(1)
        affinity = None
        block    = []
        i += 1
        while i < len(lines):
            if lines[i] == '!':   # bare '!' at col 0 = end of top-level block
                break
            am = re.match(r'^\s+affinity\s+(\d+)', lines[i])
            if am:
                affinity = int(am.group(1))
            block.append(lines[i])
            i += 1
        routers[name] = {"affinity": affinity, "block": block}
    i += 1

my_info  = routers.get(instance, {})
my_block = my_info.get("block", [])

# --------------------------------------------------------------------------
# Check 1: affinity conflicts
#
# A single xcespproc process can only reside in one Linux network namespace
# at a time.  Two router nodes with the same affinity would both be deployed
# to the same xcespproc instance, which cannot operate in two namespaces.
# --------------------------------------------------------------------------
my_affinity = my_info.get("affinity")
for other, info in sorted(routers.items()):
    if other != instance and info["affinity"] == my_affinity:
        aff_str = str(my_affinity) if my_affinity is not None else "unset (default)"
        print(f"affinity {aff_str} is also assigned to router '{other}'; "
              f"each xcespproc instance can manage at most one network namespace")

# --------------------------------------------------------------------------
# Check 1b: active dynamic-routing requires affinity
#
# dynamic-routing starts an FRR instance scoped to the router's network
# namespace.  xcespproc instances are namespace-bound (one namespace per
# process).  Without an explicit affinity the router falls into the default
# xcespproc slot (affinity unset), which may be shared with other routers;
# xcespproc cannot operate in two namespaces simultaneously.
#
# Rule: if this router has a 'dynamic-routing' child block whose 'shutdown'
# attribute is false (or absent — default is false), the router must have an
# explicit 'affinity' set.
# --------------------------------------------------------------------------
def _dr_is_active(block):
    """Return True if the block contains a dynamic-routing child that is not
    explicitly shut down (shutdown absent or false)."""
    n = len(block)
    j = 0
    while j < n:
        m = re.match(r'^(\s+)dynamic-routing', block[j])
        if m:
            indent   = m.group(1)
            shutdown = False
            j += 1
            while j < n:
                if re.match(r'^' + re.escape(indent) + r'!', block[j]):
                    break
                if re.match(r'^\s+shutdown\s+true', block[j]):
                    shutdown = True
                j += 1
            if not shutdown:
                return True
        j += 1
    return False

if my_affinity is None and _dr_is_active(my_block):
    print("dynamic-routing is active (no shutdown) but router has no 'affinity' set; "
          "an explicit affinity is required so xcespproc can be bound to this "
          "router's namespace exclusively")

# --------------------------------------------------------------------------
# Check 2: address instance names — must be a valid IP address with prefix length
#
# The instance name of an 'address' node is the IP address/prefix to assign
# to the interface (e.g. 192.168.1.1/24 or 2001:db8::1/64).  A bare address
# without a prefix length is rejected.
# --------------------------------------------------------------------------
for line in my_block:
    m = re.match(r'^\s+address\s+(\S+)', line)
    if m:
        addr = m.group(1)
        if '/' not in addr:
            print(f"address '{addr}': prefix length required "
                  f"(e.g. 192.168.1.1/24 or 2001:db8::1/64)")
            continue
        try:
            ipaddress.ip_interface(addr)
        except ValueError:
            print(f"address '{addr}': not a valid IP address with prefix length")

# --------------------------------------------------------------------------
# Check 3: static-route instance names — must be a valid IP network prefix
#
# The instance name of a 'static-route' node is the destination network
# (e.g. 192.168.1.0/24 or 2001:db8::/32).  A bare address without a prefix
# length is rejected; host bits set in a network address are allowed.
# --------------------------------------------------------------------------
for line in my_block:
    m = re.match(r'^\s+static-route\s+(\S+)', line)
    if m:
        net = m.group(1)
        if '/' not in net:
            print(f"static-route '{net}': prefix length required "
                  f"(e.g. 192.168.1.0/24 or 2001:db8::/32)")
            continue
        try:
            ipaddress.ip_network(net, strict=False)
        except ValueError:
            print(f"static-route '{net}': not a valid IP network prefix")

# --------------------------------------------------------------------------
# Helper: parse interface blocks from a router block
#
# Returns a list of dicts:
#   {"name": str, "attrs": {k: v}, "shutdown": bool}
# Works at any nesting depth by tracking indentation.
# --------------------------------------------------------------------------
def _parse_interfaces(block):
    """Scan block lines for all 'interface <name>' sub-blocks and return a
    list of {name, attrs, shutdown} dicts.

    An interface *node* is closed by a '!' at the same indent level.  An
    'interface' attribute line inside a vlan block has no such closer, so it
    is silently skipped (found_closer guard).
    """
    ifaces = []
    n = len(block)
    j = 0
    while j < n:
        m = re.match(r'^(\s+)interface\s+(\S+)', block[j])
        if m:
            indent       = m.group(1)
            name         = m.group(2)
            attrs        = {}
            found_closer = False
            j += 1
            # collect lines inside this interface block until its '!' closer
            while j < n:
                close = re.match(r'^' + re.escape(indent) + r'!', block[j])
                if close:
                    j += 1
                    found_closer = True
                    break
                # A non-'!' line at the same or lesser indent means this
                # 'interface' line is an attribute (e.g. inside a vlan block),
                # not a block header.  Stop scanning to avoid matching a '!'
                # that belongs to a sibling child block.
                cur_line_indent = len(block[j]) - len(block[j].lstrip())
                if cur_line_indent <= len(indent):
                    break
                am = re.match(r'^\s+(\S+)\s+(\S+)', block[j])
                if am:
                    attrs[am.group(1)] = am.group(2)
                bm = re.match(r'^\s+no\s+shutdown', block[j])
                if bm:
                    attrs["shutdown"] = "false"
                bm2 = re.match(r'^\s+shutdown\s+false', block[j])
                if bm2:
                    attrs["shutdown"] = "false"
                j += 1
            # Only accept entries where a proper '!' closer was found.
            # Attribute lines named 'interface' (e.g. inside a vlan block)
            # never have a matching closer at their indent level.
            if not found_closer:
                continue
            raw_shut = attrs.get("shutdown", "false")
            ifaces.append({
                "name":     name,
                "attrs":    attrs,
                "shutdown": raw_shut == "true",
            })
        else:
            j += 1
    return ifaces

# --------------------------------------------------------------------------
# Helper: parse vrf sub-blocks from a router block
#
# Yields (vrf_name, vrf_lines) for each 'vrf <name>' sub-block.
# --------------------------------------------------------------------------
def _parse_vrf_blocks(block):
    n = len(block)
    j = 0
    while j < n:
        m = re.match(r'^(\s+)vrf\s+(\S+)', block[j])
        if m:
            indent    = m.group(1)
            vrf_name  = m.group(2)
            vrf_lines = []
            j += 1
            while j < n:
                if re.match(r'^' + re.escape(indent) + r'!', block[j]):
                    j += 1
                    break
                vrf_lines.append(block[j])
                j += 1
            yield vrf_name, vrf_lines
        else:
            j += 1

# --------------------------------------------------------------------------
# Check 4: type 'device' interfaces must specify 'device'
#
# 'type device' (the default) references an *existing* Linux interface and
# must always name it explicitly.  Synthetic types ('loopback', 'rlink',
# 'gre') all auto-derive the device name from the interface instance name
# and therefore do not require an explicit 'device' attribute.
#
# Scanned per-VRF so that 'interface <name>' attribute lines inside vlan
# nodes are not mistaken for interface node declarations.
# --------------------------------------------------------------------------
for _vrf_name4, _vrf_lines4 in _parse_vrf_blocks(my_block):
    for iface in _parse_interfaces(_vrf_lines4):
        iface_type = iface["attrs"].get("type", "device")
        if iface_type == "device" and "device" not in iface["attrs"]:
            print(f"interface '{iface['name']}': 'device' attribute is required "
                  f"for type 'device'")

# --------------------------------------------------------------------------
# Check 5: rlink (not shutdown) must specify 'link'
# --------------------------------------------------------------------------
for _vrf_name5, _vrf_lines5 in _parse_vrf_blocks(my_block):
    for iface in _parse_interfaces(_vrf_lines5):
        if iface["attrs"].get("type") == "rlink" and not iface["shutdown"]:
            if "link" not in iface["attrs"]:
                print(f"interface '{iface['name']}': 'link' attribute is required "
                      f"for type 'rlink' when not shutdown")

# --------------------------------------------------------------------------
# Check 6: exactly 2 active rlink interfaces must share the same link name
#          (checked once for the LAST router in sorted order to emit once)
# --------------------------------------------------------------------------
if instance == sorted(routers.keys())[-1]:
    link_map = {}  # link_name -> list of "router/iface"
    for rname, rinfo in routers.items():
        for _vn6, _vl6 in _parse_vrf_blocks(rinfo["block"]):
            for iface in _parse_interfaces(_vl6):
                if iface["attrs"].get("type") == "rlink" and not iface["shutdown"]:
                    ln = iface["attrs"].get("link", "")
                    if ln:
                        link_map.setdefault(ln, []).append(f"{rname}/{iface['name']}")
    for link_name, owners in sorted(link_map.items()):
        if len(owners) != 2:
            print(f"link '{link_name}': exactly 2 active rlink interfaces required "
                  f"(found {len(owners)}: {', '.join(owners)})")

# --------------------------------------------------------------------------
# Helper: parse vlan blocks from a router/vrf block
#
# Returns a list of dicts:
#   {"name": str, "attrs": {k: v}, "shutdown": bool}
# --------------------------------------------------------------------------
def _parse_vlans(block):
    vlans = []
    n = len(block)
    j = 0
    while j < n:
        m = re.match(r'^(\s+)vlan\s+(\S+)', block[j])
        if m:
            indent = m.group(1)
            name   = m.group(2)
            attrs  = {}
            j += 1
            while j < n:
                if re.match(r'^' + re.escape(indent) + r'!', block[j]):
                    j += 1
                    break
                am = re.match(r'^\s+(\S+)\s+(\S+)', block[j])
                if am:
                    attrs[am.group(1)] = am.group(2)
                j += 1
            raw_shut = attrs.get("shutdown", "false")
            vlans.append({
                "name":     name,
                "attrs":    attrs,
                "shutdown": raw_shut == "true",
            })
        else:
            j += 1
    return vlans

# --------------------------------------------------------------------------
# Check 7: vlan 'interface' attr must reference a known interface in the
#          same VRF block
# Check 8: vlan parent interface must not be type loopback
#
# Both checks are skipped for cross-namespace VLANs (parent-router present);
# those are validated by check 9 instead.
# --------------------------------------------------------------------------
for _vrf_name, _vrf_lines in _parse_vrf_blocks(my_block):
    _iface_map = {i["name"]: i for i in _parse_interfaces(_vrf_lines)}
    for _vlan in _parse_vlans(_vrf_lines):
        if _vlan["shutdown"]:
            continue
        if _vlan["attrs"].get("parent-router", ""):
            continue  # cross-namespace VLAN — validated by check 9
        _ref = _vlan["attrs"].get("interface", "")
        if not _ref:
            print(f"vlan '{_vlan['name']}': 'interface' attribute is required")
            continue
        if _ref not in _iface_map:
            print(f"vlan '{_vlan['name']}': interface '{_ref}' not found "
                  f"in vrf '{_vrf_name}'")
            continue
        _iface_type = _iface_map[_ref]["attrs"].get("type", "device")
        if _iface_type == "loopback":
            print(f"vlan '{_vlan['name']}': cannot create 802.1Q VLAN on "
                  f"loopback interface '{_ref}'")

# --------------------------------------------------------------------------
# Check 9: 'parent-router' must reference a known router (and not itself);
#          'interface' must be a known interface instance name in that router
#
# Cross-namespace VLANs rely on xcespproc being able to run ip commands in
# the parent router's namespace.  A non-existent parent-router causes a
# runtime failure; referencing the same router should use a plain 'interface'
# reference instead.
#
# 'interface' is the XCESP instance name (e.g. eth1), consistent with the
# same-namespace case.  xcespmap resolves the instance name to the Linux
# device name at commit time via the full config.  We validate here that
# the named instance actually exists in the parent router.
# --------------------------------------------------------------------------
for _vrf_name, _vrf_lines in _parse_vrf_blocks(my_block):
    for _vlan in _parse_vlans(_vrf_lines):
        if _vlan["shutdown"]:
            continue
        _pr = _vlan["attrs"].get("parent-router", "")
        if not _pr:
            continue
        if _pr == instance:
            print(f"vlan '{_vlan['name']}': parent-router '{_pr}' is the same "
                  f"router — use a plain 'interface' reference instead")
            continue
        if _pr not in routers:
            print(f"vlan '{_vlan['name']}': parent-router '{_pr}' not found in config")
            continue
        # Collect all interface instance names from the parent router
        _parent_instances = set()
        for _pvn, _pvl in _parse_vrf_blocks(routers[_pr]["block"]):
            for _piface in _parse_interfaces(_pvl):
                _parent_instances.add(_piface["name"])
        _iface_ref = _vlan["attrs"].get("interface", "")
        if not _iface_ref:
            print(f"vlan '{_vlan['name']}': 'interface' attribute is required")
        elif _parent_instances and _iface_ref not in _parent_instances:
            _hint = ", ".join(sorted(_parent_instances)) if _parent_instances else "none found"
            print(f"vlan '{_vlan['name']}': interface '{_iface_ref}' is not a known "
                  f"interface instance in router '{_pr}'; known: {_hint}")

# --------------------------------------------------------------------------
# Helper: parse bgp/bgp-vrf/bgp-view blocks from a vrf block
#
# Returns a list of dicts:
#   {"node": str,   # "bgp", "bgp-vrf", or "bgp-view"
#    "name": str,   # instance name (ASN for bgp, vrf/view name for others)
#    "attrs": {k: v},
#    "shutdown": bool}
# --------------------------------------------------------------------------
def _parse_bgp_instances(vrf_lines):
    instances = []
    n = len(vrf_lines)
    j = 0
    while j < n:
        m = re.match(r'^(\s+)(bgp|bgp-vrf|bgp-view)\s+(\S+)', vrf_lines[j])
        if m:
            indent    = m.group(1)
            node_kind = m.group(2)
            name      = m.group(3)
            attrs     = {}
            j += 1
            while j < n:
                if re.match(r'^' + re.escape(indent) + r'!', vrf_lines[j]):
                    j += 1
                    break
                cur_indent = len(vrf_lines[j]) - len(vrf_lines[j].lstrip())
                if cur_indent <= len(indent):
                    break
                # Handle both "shutdown false" and "no shutdown" forms
                if re.match(r'^\s+no\s+shutdown', vrf_lines[j]):
                    attrs["shutdown"] = "false"
                elif re.match(r'^\s+shutdown\s+false', vrf_lines[j]):
                    attrs["shutdown"] = "false"
                else:
                    am = re.match(r'^\s+(\S+)\s+(\S+)', vrf_lines[j])
                    if am:
                        attrs[am.group(1)] = am.group(2)
                j += 1
            # shutdown default is true for all BGP node types
            raw_shut = attrs.get("shutdown", "true")
            instances.append({
                "node":     node_kind,
                "name":     name,
                "attrs":    attrs,
                "shutdown": raw_shut == "true",
            })
        else:
            j += 1
    return instances

# --------------------------------------------------------------------------
# Check 10: bgp instance name must be a valid ASN (integer 1–4294967295)
# --------------------------------------------------------------------------
for _vrf_name10, _vrf_lines10 in _parse_vrf_blocks(my_block):
    for _bgp in _parse_bgp_instances(_vrf_lines10):
        if _bgp["node"] != "bgp":
            continue
        asn_str = _bgp["name"]
        try:
            asn_val = int(asn_str)
            if not (1 <= asn_val <= 4294967295):
                raise ValueError
        except ValueError:
            print(f"bgp '{asn_str}' in vrf '{_vrf_name10}': instance name must be "
                  f"a valid ASN (integer 1–4294967295)")

# --------------------------------------------------------------------------
# Check 11: router-id must not be 0.0.0.0 when shutdown is false
#
# A zero router-id is undefined in BGP: FRR may pick one automatically, but
# this is non-deterministic and not acceptable in production.  Enforce it at
# commit time for all four BGP instance types.
# --------------------------------------------------------------------------
for _vrf_name11, _vrf_lines11 in _parse_vrf_blocks(my_block):
    for _bgp in _parse_bgp_instances(_vrf_lines11):
        if _bgp["shutdown"]:
            continue
        rid = _bgp["attrs"].get("router-id", "0.0.0.0")
        if rid == "0.0.0.0":
            print(f"{_bgp['node']} '{_bgp['name']}' in vrf '{_vrf_name11}': "
                  f"router-id must not be 0.0.0.0 when shutdown is false")

# --------------------------------------------------------------------------
# Check 12: bgp-vrf and bgp-view require a sibling 'bgp' instance in the
#           same vrf block (to resolve the ASN)
# --------------------------------------------------------------------------
for _vrf_name12, _vrf_lines12 in _parse_vrf_blocks(my_block):
    _bgp_insts = _parse_bgp_instances(_vrf_lines12)
    _has_bgp   = any(b["node"] == "bgp" for b in _bgp_insts)
    for _bgp in _bgp_insts:
        if _bgp["node"] in ("bgp-vrf", "bgp-view") and not _has_bgp:
            print(f"{_bgp['node']} '{_bgp['name']}' in vrf '{_vrf_name12}': "
                  f"no sibling 'bgp <ASN>' instance found; "
                  f"bgp-vrf and bgp-view inherit the ASN from the sibling bgp instance")

# --------------------------------------------------------------------------
# Check 13: dynamic-routing bgp must be enabled when any BGP instance is
#           active (shutdown=false)
#
# bgp=true on the dynamic-routing child tells xcespproc to start bgpd.
# Without it, FRR will not run bgpd and all BGP stanzas are silently ignored.
# --------------------------------------------------------------------------
def _dr_bgp_enabled(block):
    """Return True if the block has a dynamic-routing child with bgp=true."""
    n = len(block)
    j = 0
    while j < n:
        m = re.match(r'^(\s+)dynamic-routing', block[j])
        if m:
            indent = m.group(1)
            j += 1
            while j < n:
                if re.match(r'^' + re.escape(indent) + r'!', block[j]):
                    break
                if re.match(r'^\s+bgp(\s+true)?\s*$', block[j]):
                    return True
                j += 1
        j += 1
    return False

_any_bgp_active = False
for _vrf_name13, _vrf_lines13 in _parse_vrf_blocks(my_block):
    for _bgp in _parse_bgp_instances(_vrf_lines13):
        if not _bgp["shutdown"]:
            _any_bgp_active = True
            break

if _any_bgp_active and not _dr_bgp_enabled(my_block):
    print(f"router '{instance}': has active BGP instance(s) (shutdown=false) "
          f"but dynamic-routing 'bgp' is not enabled; "
          f"add 'bgp' under 'dynamic-routing' to start bgpd")

# --------------------------------------------------------------------------
# Check 14: at most one 'bgp <ASN>' per VRF block; all bgp-vrf and bgp-view
#           instances within a VRF must share the same ASN
#
# FRR allows only one BGP speaker per VRF at the process level.  Two 'bgp'
# entries in the same VRF (even with the same ASN) are duplicates; two with
# different ASNs would produce conflicting 'router bgp' stanzas.
# bgp-vrf and bgp-view inherit the ASN from the sibling 'bgp' instance, so
# they are implicitly correct once the single-bgp rule is enforced.
# --------------------------------------------------------------------------
for _vrf_name14, _vrf_lines14 in _parse_vrf_blocks(my_block):
    _bgp_insts14 = _parse_bgp_instances(_vrf_lines14)
    _bgp_mains   = [b for b in _bgp_insts14 if b["node"] == "bgp"]
    if len(_bgp_mains) > 1:
        _asns = [b["name"] for b in _bgp_mains]
        if len(set(_asns)) == 1:
            print(f"vrf '{_vrf_name14}': duplicate 'bgp {_asns[0]}' instance "
                  f"({len(_bgp_mains)} entries); only one bgp instance is allowed per VRF")
        else:
            print(f"vrf '{_vrf_name14}': multiple bgp instances with different ASNs "
                  f"({', '.join(_asns)}) — only one ASN is allowed per VRF; "
                  f"use bgp-vrf or bgp-view for additional BGP instances")

# --------------------------------------------------------------------------
# Helper: extract address-family instance names from inside a single BGP block
#
# Returns a list of AFI-SAFI strings (e.g. ["ipv4-unicast", "l2vpn-evpn"]).
# --------------------------------------------------------------------------
def _parse_bgp_address_families(vrf_lines, bgp_node, bgp_name):
    """Extract address-family children of a specific bgp/bgp-vrf/bgp-view instance."""
    afs = []
    n = len(vrf_lines)
    j = 0
    # Find the matching bgp instance header
    while j < n:
        m = re.match(r'^(\s+)(bgp|bgp-vrf|bgp-view)\s+(\S+)', vrf_lines[j])
        if m and m.group(2) == bgp_node and m.group(3) == bgp_name:
            base_indent = m.group(1)
            j += 1
            # Walk children of this bgp instance until '!' at base_indent
            while j < n:
                if re.match(r'^' + re.escape(base_indent) + r'!', vrf_lines[j]):
                    break
                af_m = re.match(r'^\s+address-family\s+(\S+)', vrf_lines[j])
                if af_m:
                    afs.append(af_m.group(1))
                j += 1
            break
        j += 1
    return afs

# --------------------------------------------------------------------------
# Check 15: vpn and labeled-unicast SAFIs are only allowed in the core BGP
#           instance (bgp <ASN> inside vrf default).  Non-core instances
#           (bgp in named VRF, bgp-vrf, bgp-view) may only declare unicast,
#           multicast, or evpn SAFIs.
# --------------------------------------------------------------------------
_RESTRICTED_SAFIS = ("vpn", "labeled-unicast")

for _vrf_name15, _vrf_lines15 in _parse_vrf_blocks(my_block):
    for _bgp in _parse_bgp_instances(_vrf_lines15):
        # "core" = bgp instance inside vrf default
        is_core = (_bgp["node"] == "bgp" and _vrf_name15 == "default")
        if is_core:
            continue
        afs = _parse_bgp_address_families(_vrf_lines15, _bgp["node"], _bgp["name"])
        for af in afs:
            # AFI-SAFI is e.g. "ipv4-unicast", "ipv4-vpn", "ipv4-labeled-unicast"
            # Restricted if it ends with "-vpn" or "-labeled-unicast"
            for restricted in _RESTRICTED_SAFIS:
                if af.endswith("-" + restricted):
                    print(f"{_bgp['node']} '{_bgp['name']}' in vrf '{_vrf_name15}': "
                          f"address-family '{af}' not supported in non-core BGP instances. "
                          f"Only Unicast/Multicast/EVPN SAFIs supported in non-core instances.")
                    break

# --------------------------------------------------------------------------
# Helper: extract attrs of a specific address-family inside a specific
#         bgp/bgp-vrf/bgp-view instance.
#
# Returns a dict of attr name → value.  Single-token lines (boolean shorthand)
# are stored as value "true".  af-neighbor / af-redistribute child blocks
# are skipped.
# --------------------------------------------------------------------------
def _parse_bgp_af_attrs(vrf_lines, bgp_node, bgp_name, af_name):
    attrs = {}
    n = len(vrf_lines)
    j = 0
    while j < n:
        m = re.match(r'^(\s+)(bgp|bgp-vrf|bgp-view)\s+(\S+)', vrf_lines[j])
        if m and m.group(2) == bgp_node and m.group(3) == bgp_name:
            bgp_indent = m.group(1)
            j += 1
            while j < n:
                if re.match(r'^' + re.escape(bgp_indent) + r'!', vrf_lines[j]):
                    return attrs
                af_m = re.match(r'^(\s+)address-family\s+(\S+)', vrf_lines[j])
                if af_m and af_m.group(2) == af_name:
                    af_indent = af_m.group(1)
                    j += 1
                    # Walk children of this address-family until matching '!'
                    skip_until_indent = None
                    while j < n:
                        if re.match(r'^' + re.escape(af_indent) + r'!', vrf_lines[j]):
                            return attrs
                        cur_indent_len = len(vrf_lines[j]) - len(vrf_lines[j].lstrip())
                        # Skip nested af-neighbor / af-redistribute child blocks
                        if skip_until_indent is not None:
                            if cur_indent_len <= skip_until_indent:
                                skip_until_indent = None
                            else:
                                j += 1
                                continue
                        nested = re.match(r'^\s+(af-neighbor|af-redistribute)\s+\S+', vrf_lines[j])
                        if nested:
                            skip_until_indent = cur_indent_len
                            j += 1
                            continue
                        # Two-token attr line
                        am = re.match(r'^\s+(\S+)\s+(\S+)', vrf_lines[j])
                        if am:
                            attrs[am.group(1)] = am.group(2)
                        else:
                            # Single-token boolean line
                            sm = re.match(r'^\s+(\S+)\s*$', vrf_lines[j])
                            if sm:
                                attrs[sm.group(1)] = "true"
                        j += 1
                    return attrs
                j += 1
            return attrs
        j += 1
    return attrs

# --------------------------------------------------------------------------
# Check 16: VPN/import/export/rd/rt/label/sid attrs are only valid when
#           SAFI is unicast (ipv4-unicast or ipv6-unicast).
# --------------------------------------------------------------------------
_UNICAST_ONLY_AF_ATTRS = {
    "export-vpn", "import-vpn", "import-vrf", "import-vrf-route-map",
    "label-vpn-export-fixed", "label-vpn-export-auto-per-next-hop",
    "label-vpn-export-auto-per-vrf", "nexthop-vpn-export", "rd-vpn-export",
    "route-map-vpn-export", "route-map-vpn-import",
    "rt-redirect-import", "rt-vpn-import", "rt-vpn-export", "rt-vpn-both",
    "rt6-redirect-import", "rt6-vpn-import", "rt6-vpn-export", "rt6-vpn-both",
    "sid-vpn-export-fixed", "sid-vpn-export-auto",
}

for _vrf_name16, _vrf_lines16 in _parse_vrf_blocks(my_block):
    for _bgp16 in _parse_bgp_instances(_vrf_lines16):
        for _af_name16 in _parse_bgp_address_families(
                _vrf_lines16, _bgp16["node"], _bgp16["name"]):
            if _af_name16 in ("ipv4-unicast", "ipv6-unicast"):
                continue
            af_attrs = _parse_bgp_af_attrs(
                _vrf_lines16, _bgp16["node"], _bgp16["name"], _af_name16)
            for k in af_attrs:
                if k in _UNICAST_ONLY_AF_ATTRS:
                    print(f"{_bgp16['node']} '{_bgp16['name']}' in vrf "
                          f"'{_vrf_name16}': address-family '{_af_name16}' "
                          f"attribute '{k}' is only supported in unicast "
                          f"SAFIs (ipv4-unicast or ipv6-unicast)")
                    break  # one error per AF block is enough

# --------------------------------------------------------------------------
# Helper: extract child block names of a specific address-family inside a
# specific bgp instance.  Returns a set of child node type names.
# --------------------------------------------------------------------------
def _parse_bgp_af_children(vrf_lines, bgp_node, bgp_name, af_name):
    children = set()
    n = len(vrf_lines)
    j = 0
    while j < n:
        m = re.match(r'^(\s+)(bgp|bgp-vrf|bgp-view)\s+(\S+)', vrf_lines[j])
        if m and m.group(2) == bgp_node and m.group(3) == bgp_name:
            bgp_indent = m.group(1)
            j += 1
            while j < n:
                if re.match(r'^' + re.escape(bgp_indent) + r'!', vrf_lines[j]):
                    return children
                af_m = re.match(r'^(\s+)address-family\s+(\S+)', vrf_lines[j])
                if af_m and af_m.group(2) == af_name:
                    af_indent = af_m.group(1)
                    j += 1
                    skip_until_indent = None
                    while j < n:
                        if re.match(r'^' + re.escape(af_indent) + r'!', vrf_lines[j]):
                            return children
                        cur_indent_len = len(vrf_lines[j]) - len(vrf_lines[j].lstrip())
                        if skip_until_indent is not None:
                            if cur_indent_len <= skip_until_indent:
                                skip_until_indent = None
                            else:
                                j += 1
                                continue
                        # Look for child block headers (2 tokens, opens a sub-block)
                        cb = re.match(
                            r'^\s+(bgp-dampening|aggregate-address|af-distance|af-neighbor|af-redistribute)(\s+\S+)?',
                            vrf_lines[j])
                        if cb:
                            children.add(cb.group(1))
                            skip_until_indent = cur_indent_len
                        j += 1
                    return children
                j += 1
            return children
        j += 1
    return children

# --------------------------------------------------------------------------
# Check 17: per-SAFI attribute / child compatibility for address-family.
#
# Some AF attrs and children are only valid in specific SAFIs:
#   bgp-retain-route-target-all          → vpn
#   maximum-paths*                        → unicast, labeled-unicast
#   distance-bgp-{external,internal,local} → unicast, multicast
#   bgp-dampening (child)                 → unicast, multicast, labeled-unicast
#   aggregate-address (child)             → unicast, multicast, labeled-unicast
#   af-distance (child)                   → unicast, multicast
# --------------------------------------------------------------------------
def _af_safi(af_name):
    """Map AF instance name → SAFI label used in compatibility rules."""
    if af_name in ("ipv4-unicast", "ipv6-unicast"):           return "unicast"
    if af_name in ("ipv4-multicast", "ipv6-multicast"):       return "multicast"
    if af_name in ("ipv4-labeled-unicast", "ipv6-labeled-unicast"):
        return "labeled-unicast"
    if af_name in ("ipv4-vpn", "ipv6-vpn"):                   return "vpn"
    if af_name == "l2vpn-evpn":                                return "evpn"
    return ""

_AF_ATTR_SAFI_RULES = {
    "bgp-retain-route-target-all":              {"vpn"},
    "maximum-paths":                             {"unicast", "labeled-unicast"},
    "maximum-paths-ibgp":                        {"unicast", "labeled-unicast"},
    "maximum-paths-ibgp-equal-cluster-length":   {"unicast", "labeled-unicast"},
    "distance-bgp-external":                     {"unicast", "multicast"},
    "distance-bgp-internal":                     {"unicast", "multicast"},
    "distance-bgp-local":                        {"unicast", "multicast"},
}

_AF_CHILD_SAFI_RULES = {
    "bgp-dampening":     {"unicast", "multicast", "labeled-unicast"},
    "aggregate-address": {"unicast", "multicast", "labeled-unicast"},
    "af-distance":       {"unicast", "multicast"},
}

for _vrf_name17, _vrf_lines17 in _parse_vrf_blocks(my_block):
    for _bgp17 in _parse_bgp_instances(_vrf_lines17):
        for _af_name17 in _parse_bgp_address_families(
                _vrf_lines17, _bgp17["node"], _bgp17["name"]):
            safi = _af_safi(_af_name17)
            if not safi:
                continue
            # Attrs
            af_attrs17 = _parse_bgp_af_attrs(
                _vrf_lines17, _bgp17["node"], _bgp17["name"], _af_name17)
            for k, allowed in _AF_ATTR_SAFI_RULES.items():
                if k in af_attrs17 and safi not in allowed:
                    print(f"{_bgp17['node']} '{_bgp17['name']}' in vrf "
                          f"'{_vrf_name17}': address-family '{_af_name17}' "
                          f"attribute '{k}' is not supported in SAFI '{safi}' "
                          f"(allowed SAFIs: {', '.join(sorted(allowed))})")
            # Child blocks
            af_children17 = _parse_bgp_af_children(
                _vrf_lines17, _bgp17["node"], _bgp17["name"], _af_name17)
            for child, allowed in _AF_CHILD_SAFI_RULES.items():
                if child in af_children17 and safi not in allowed:
                    print(f"{_bgp17['node']} '{_bgp17['name']}' in vrf "
                          f"'{_vrf_name17}': address-family '{_af_name17}' "
                          f"child '{child}' is not supported in SAFI '{safi}' "
                          f"(allowed SAFIs: {', '.join(sorted(allowed))})")

# --------------------------------------------------------------------------
# Helper: collect attrs of all af-neighbor children inside a specific
# address-family of a specific bgp instance.
#
# Returns a list of (peer_name, attrs_dict) tuples.
# --------------------------------------------------------------------------
def _parse_af_neighbors(vrf_lines, bgp_node, bgp_name, af_name):
    result = []
    n = len(vrf_lines)
    j = 0
    while j < n:
        m = re.match(r'^(\s+)(bgp|bgp-vrf|bgp-view)\s+(\S+)', vrf_lines[j])
        if m and m.group(2) == bgp_node and m.group(3) == bgp_name:
            bgp_indent = m.group(1)
            j += 1
            while j < n:
                if re.match(r'^' + re.escape(bgp_indent) + r'!', vrf_lines[j]):
                    return result
                af_m = re.match(r'^(\s+)address-family\s+(\S+)', vrf_lines[j])
                if af_m and af_m.group(2) == af_name:
                    af_indent = af_m.group(1)
                    j += 1
                    while j < n:
                        if re.match(r'^' + re.escape(af_indent) + r'!', vrf_lines[j]):
                            return result
                        nbr_m = re.match(r'^(\s+)af-neighbor\s+(\S+)', vrf_lines[j])
                        if nbr_m:
                            nbr_indent = nbr_m.group(1)
                            peer_name  = nbr_m.group(2)
                            nbr_attrs  = {}
                            j += 1
                            # Walk children of this af-neighbor until matching '!'
                            while j < n:
                                if re.match(r'^' + re.escape(nbr_indent) + r'!', vrf_lines[j]):
                                    j += 1
                                    break
                                # Two-token attr line
                                am = re.match(r'^\s+(\S+)\s+(\S+)', vrf_lines[j])
                                if am:
                                    nbr_attrs[am.group(1)] = am.group(2)
                                else:
                                    sm = re.match(r'^\s+(\S+)\s*$', vrf_lines[j])
                                    if sm:
                                        nbr_attrs[sm.group(1)] = "true"
                                j += 1
                            result.append((peer_name, nbr_attrs))
                            continue
                        j += 1
                    return result
                j += 1
            return result
        j += 1
    return result

# --------------------------------------------------------------------------
# Check 18: capability-orf-prefix-list-* attrs are not allowed in vpn SAFI.
# --------------------------------------------------------------------------
_AF_NBR_VPN_FORBIDDEN = {
    "capability-orf-prefix-list-both",
    "capability-orf-prefix-list-receive",
    "capability-orf-prefix-list-send",
}

for _vrf_name18, _vrf_lines18 in _parse_vrf_blocks(my_block):
    for _bgp18 in _parse_bgp_instances(_vrf_lines18):
        for _af_name18 in _parse_bgp_address_families(
                _vrf_lines18, _bgp18["node"], _bgp18["name"]):
            safi = _af_safi(_af_name18)
            if safi != "vpn":
                continue
            for peer, nbr_attrs in _parse_af_neighbors(
                    _vrf_lines18, _bgp18["node"], _bgp18["name"], _af_name18):
                for k in nbr_attrs:
                    if k in _AF_NBR_VPN_FORBIDDEN:
                        print(f"{_bgp18['node']} '{_bgp18['name']}' in vrf "
                              f"'{_vrf_name18}': address-family '{_af_name18}' "
                              f"af-neighbor '{peer}' attribute '{k}' is not "
                              f"supported in vpn SAFI")
                        break  # one error per neighbor is enough
