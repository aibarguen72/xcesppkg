"""xcesppy.client — XCespClient: xcespserver CLI protocol client.

Wire format (identical to xcespcli CliProtocol):
    VERB BODYLEN\\n<body: exactly BODYLEN bytes>\\n

State machine:
    connect() → CLI_HELLO → CLI_ACK → READY
    READY → get_config / put_config / merge_config / save_config / get_status
             get_events / get_alarms / get_active_alarms
             get_summary_alarms / get_summary_events
    disconnect() → close socket
"""

import json
import socket

from . import config as _cfg


class XCespError(Exception):
    """Raised on protocol errors, NAK responses, or connection failures."""


# ---------------------------------------------------------------------------
# Low-level frame codec
# ---------------------------------------------------------------------------

def _send_frame(sock: socket.socket, verb: str, body: str = '') -> None:
    b = body.encode('utf-8')
    header = f"{verb} {len(b)}\n".encode('utf-8')
    sock.sendall(header + b + b'\n')


def _recv_frame(sock: socket.socket) -> tuple:
    """Receive one frame and return (verb, body_str)."""
    # Read header byte by byte until '\\n'
    hdr = b''
    while True:
        ch = sock.recv(1)
        if not ch:
            raise XCespError("connection closed while reading frame header")
        hdr += ch
        if ch == b'\n':
            break

    parts = hdr.decode('utf-8').strip().split(' ', 1)
    if len(parts) != 2:
        raise XCespError(f"malformed frame header: {hdr!r}")
    verb = parts[0]
    try:
        n = int(parts[1])
    except ValueError as exc:
        raise XCespError(f"invalid body length '{parts[1]}' in frame") from exc

    # Read exactly n body bytes + trailing '\\n'
    buf = b''
    needed = n + 1
    while len(buf) < needed:
        chunk = sock.recv(needed - len(buf))
        if not chunk:
            raise XCespError("connection closed while reading frame body")
        buf += chunk

    return verb, buf[:n].decode('utf-8')


def _parse_kv(body: str) -> dict:
    """Parse 'KEY=VALUE\\n...' body into a dict."""
    result = {}
    for line in body.splitlines():
        eq = line.find('=')
        if eq >= 0:
            result[line[:eq]] = line[eq + 1:].rstrip('\r')
    return result


# ---------------------------------------------------------------------------
# XCespClient
# ---------------------------------------------------------------------------

class XCespClient:
    """Client for xcespserver's CLI protocol.

    Parameters
    ----------
    host : str
        xcespserver address (default '127.0.0.1').
    port : int
        xcespserver CONTROL_PORT (default 9900).
    timeout : float
        Socket receive timeout in seconds (default 30).
    sock_path : str
        If set, connect via Unix Domain Socket at this path instead of TCP.
        Takes precedence over host/port.

    Usage::

        with XCespClient() as cli:
            cli.put_config("...")
            status = cli.get_status()
    """

    def __init__(self, host: str = '127.0.0.1', port: int = 9900,
                 timeout: float = 30.0, sock_path: str = ''):
        self._host = host
        self._port = port
        self._timeout = timeout
        self._sock_path = sock_path
        self._sock: socket.socket | None = None

    # ------------------------------------------------------------------
    # Connection management
    # ------------------------------------------------------------------

    def connect(self) -> None:
        """Open connection (UDS or TCP) and perform CLI_HELLO handshake."""
        if self._sock_path:
            sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            sock.settimeout(self._timeout)
            try:
                sock.connect(self._sock_path)
            except OSError as exc:
                sock.close()
                raise XCespError(f"connection to {self._sock_path} failed: {exc}") from exc
        else:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(self._timeout)
            try:
                sock.connect((self._host, self._port))
            except OSError as exc:
                sock.close()
                raise XCespError(
                    f"connection to {self._host}:{self._port} failed: {exc}") from exc
        self._sock = sock

        # Handshake
        _send_frame(self._sock, 'CLI_HELLO', 'VERSION=1\n')
        verb, body = _recv_frame(self._sock)
        if verb != 'CLI_ACK':
            raise XCespError(f"CLI_HELLO: expected CLI_ACK, got {verb!r}")
        kv = _parse_kv(body)
        if kv.get('CMD') != 'CLI_HELLO':
            raise XCespError(f"CLI_HELLO ACK has unexpected CMD={kv.get('CMD')!r}")

    def disconnect(self) -> None:
        """Close the TCP connection."""
        if self._sock is not None:
            try:
                self._sock.close()
            except OSError:
                pass
            self._sock = None

    def __enter__(self) -> 'XCespClient':
        self.connect()
        return self

    def __exit__(self, *_) -> None:
        self.disconnect()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _require_connected(self) -> None:
        if self._sock is None:
            raise XCespError("not connected — call connect() or use as context manager")

    def _expect_ack(self, expected_cmd: str) -> None:
        """Receive a frame and raise XCespError unless it is CLI_ACK for expected_cmd."""
        verb, body = _recv_frame(self._sock)
        if verb == 'CLI_NAK':
            kv = _parse_kv(body)
            raise XCespError(
                f"{expected_cmd} rejected: {kv.get('REASON', 'no reason given')}")
        if verb != 'CLI_ACK':
            raise XCespError(f"{expected_cmd}: expected CLI_ACK, got {verb!r}")

    # ------------------------------------------------------------------
    # Primitives
    # ------------------------------------------------------------------

    def get_config(self, path: str = '') -> str:
        """Return the running configuration as router CLI text.

        Parameters
        ----------
        path : str
            Unused by the server (returned for future use); the full config
            is always returned.  Call ``xcesppy.config.parse_config()`` to
            work with it programmatically.
        """
        self._require_connected()
        _send_frame(self._sock, 'CLI_CONFIG_GET', f'PATH={path}\n')
        verb, body = _recv_frame(self._sock)
        if verb != 'CLI_CONFIG_DATA':
            raise XCespError(f"get_config: expected CLI_CONFIG_DATA, got {verb!r}")
        return body

    def put_config(self, text: str) -> None:
        """Replace the running configuration with *text*.

        Parameters
        ----------
        text : str
            Complete configuration in router CLI text format.  Pass an empty
            string to clear all objects.

        Raises
        ------
        XCespError
            If the server rejects the configuration (CLI_NAK).
        """
        self._require_connected()
        _send_frame(self._sock, 'CLI_CONFIG_PUT', text)
        self._expect_ack('CLI_CONFIG_PUT')

    def merge_config(self, partial: str) -> None:
        """Merge *partial* configuration into the current running config.

        Fetches the running config, deep-merges *partial* into it
        (matched by (node_type, instance)), then commits the result.
        New nodes in *partial* are appended; existing nodes have their
        attributes and children updated.

        Parameters
        ----------
        partial : str
            Partial configuration in router CLI text format.

        Raises
        ------
        XCespError
            If the server rejects the merged configuration (CLI_NAK).
        """
        base_text = self.get_config()
        merged = _cfg.merge_config(base_text, partial)
        self.put_config(merged)

    def save_config(self) -> None:
        """Persist the running configuration to the startup config file.

        Raises
        ------
        XCespError
            If the server cannot write the file (CLI_NAK).
        """
        self._require_connected()
        _send_frame(self._sock, 'CLI_SAVE', '')
        self._expect_ack('CLI_SAVE')

    def get_status(self, path: str = '') -> dict:
        """Return the global status tree as a flat dict.

        Parameters
        ----------
        path : str
            Optional prefix filter, e.g. ``'domain/main'``.
            The server returns only entries whose path starts with this string.

        Returns
        -------
        dict[str, str]
            Mapping of ``"path/to/attr"`` → ``"value"`` strings.
            Returns an empty dict if no status has been reported yet.

        Example status keys for a udpbert node at ``domain/main/udpbert/bert-a``::

            domain/main/udpbert/bert-a/status          → "ACTIVE"
            domain/main/udpbert/bert-a/sync-ok         → "true"
            domain/main/udpbert/bert-a/good-packets    → "1234"
            domain/main/udpbert/bert-a/bad-packets     → "0"
            domain/main/udpbert/bert-a/packets-sent    → "1234"
            domain/main/udpbert/bert-a/packets-received → "1234"
        """
        self._require_connected()
        _send_frame(self._sock, 'CLI_STATUS_GET', f'PATH={path}\n')
        verb, body = _recv_frame(self._sock)
        if verb != 'CLI_STATUS_DATA':
            raise XCespError(f"get_status: expected CLI_STATUS_DATA, got {verb!r}")
        if not body.strip():
            return {}
        try:
            return json.loads(body)
        except json.JSONDecodeError as exc:
            raise XCespError(f"get_status: invalid JSON in response: {exc}") from exc

    def get_events(self, path: str = '') -> list:
        """Return the event log (pure events, severity=NONE) as a list of dicts.

        Parameters
        ----------
        path : str
            Optional prefix filter, e.g. ``'domain/main'``.

        Returns
        -------
        list[dict]
            Each dict has keys: ``ts`` (int ms since epoch), ``path``,
            ``type``, ``sev``.
        """
        return self._get_event_data('CLI_EVENT_GET', 'CLI_EVENT_DATA', path)

    def get_alarms(self, path: str = '') -> list:
        """Return the alarm history (severity != NONE) as a list of dicts.

        Parameters
        ----------
        path : str
            Optional prefix filter, e.g. ``'domain/main'``.

        Returns
        -------
        list[dict]
            Each dict has keys: ``ts`` (int ms since epoch), ``path``,
            ``type``, ``sev``.
        """
        return self._get_event_data('CLI_ALARM_GET', 'CLI_ALARM_DATA', path)

    def get_active_alarms(self, path: str = '') -> list:
        """Return currently active alarms as a list of dicts.

        Parameters
        ----------
        path : str
            Optional prefix filter, e.g. ``'domain/main'``.

        Returns
        -------
        list[dict]
            Each dict has keys: ``ts``, ``path``, ``type``, ``sev``.
        """
        return self._get_event_data(
            'CLI_ACTIVE_ALARM_GET', 'CLI_ACTIVE_ALARM_DATA', path)

    def get_summary_alarms(self, path: str = '') -> list:
        """Return the alarm occurrence histogram as a list of dicts.

        Parameters
        ----------
        path : str
            Optional prefix filter.

        Returns
        -------
        list[dict]
            Each dict has keys: ``path``, ``type``, ``count`` (int),
            ``last_ts`` (int ms), ``last_sev``.
        """
        return self._get_event_data(
            'CLI_SUMMARY_ALARM_GET', 'CLI_SUMMARY_ALARM_DATA', path)

    def get_summary_events(self, path: str = '') -> list:
        """Return the event occurrence histogram as a list of dicts.

        Parameters
        ----------
        path : str
            Optional prefix filter.

        Returns
        -------
        list[dict]
            Each dict has keys: ``path``, ``type``, ``count`` (int),
            ``last_ts`` (int ms), ``last_sev``.
        """
        return self._get_event_data(
            'CLI_SUMMARY_EVENT_GET', 'CLI_SUMMARY_EVENT_DATA', path)

    # ------------------------------------------------------------------
    # Internal helper for event/alarm/summary queries
    # ------------------------------------------------------------------

    def _get_event_data(self, req_verb: str, data_verb: str,
                        path: str = '') -> list:
        self._require_connected()
        _send_frame(self._sock, req_verb, f'PATH={path}\n')
        verb, body = _recv_frame(self._sock)
        if verb != data_verb:
            raise XCespError(f"{req_verb}: expected {data_verb}, got {verb!r}")
        if not body.strip():
            return []
        try:
            return json.loads(body)
        except json.JSONDecodeError as exc:
            raise XCespError(
                f"{req_verb}: invalid JSON in response: {exc}") from exc
